using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;
using System.IO;
using RealTimeFaceRecognitionExample;
public class UIManager : MonoBehaviour
{
    public static UIManager instance;
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
    }

    public GameObject[] taskBarButtonSprites;
    public GameObject[] ToolBarPanels;
    //public GameObject[] SelectedSprites;
    public Button[] TaskBaarButton;
    public GameObject clotheFullViewPanel;

    public GameObject avatarCustomzPanel;
    public GameObject UMAObjectRoot;
    public GameObject UMAModelMale;
    public GameObject UMAModelFeMale;
    public GameObject CameraPanel;

    // public GameObject MainCamera;
    public GameObject FaceRecognizer;
    public GameObject AddPerson;
    public bool AlreadyAdded = false;
    // public Button TakePictureButton;
    public GameObject LoadingImageOfRecognizer;
    public GameObject ToolBaar;
    public GameObject TopImagePanel;
    public GameObject SignINPanel;
    public GameObject TextObjectToScann;
    private bool FirstTimeFace = true;
    public bool CameraClick = false;
    public GameObject LightSlider;
    public SelectedCharacter selectedCharacter;
    public bool CameraOff = false;
    public GameObject CongratsPanel;
    public Animator CongratsAnimator;
    private bool StartFaceDetection = false;
    public Light BrightnessLight;
    public Animator AvatarButtonAnim;
    public GameObject UseAnotherMethodToLoginButton;
    public bool AlreadyAddedButSignin = false;
    public TMPro.TextMeshProUGUI faceNotRegisteredtext;
    public bool OneTimePostAPI = true;
    public GameObject FaceOverridePanel;
    public WebCamTextureRealTimeFaceRecognitionExample WebCamTexture;
    public bool FirstTimeFaceAddedComplete =false;
    public GameObject LoadingPanel;
    // All Other Script Access Variable
    [Header("Other Scripts Variable To Access")]
    [SerializeField]
    private SoundScript _soundSriptObj;
    [SerializeField]
    private PageAnimation _pageAnimScripObj;
    public SaveCustomizeData saveDataScript;
    
    private void Update()
    {
        // if (Input.GetKeyDown(KeyCode.Space))
        // {
        //     ShopManager.instance.GetCategory();
        //     ShopUI.instance.SetCategoryUI();
        // }
    }

    public void FaceIdKeyRemover()
    {
        PlayerPrefs.DeleteKey((PlayerPrefs.GetString("Email")));
    }


    public void Start()
    {
        //PlayerPrefs.DeleteAll();
        if (_soundSriptObj == null) _soundSriptObj = FindObjectOfType<SoundScript>();
        if (_pageAnimScripObj == null) _pageAnimScripObj = FindObjectOfType<PageAnimation>();
        if (saveDataScript == null) saveDataScript = FindObjectOfType<SaveCustomizeData>();
        //PlayerPrefs.DeleteKey((PlayerPrefs.GetString("Email")));
       // if (PlayerPrefs.GetInt(PlayerPrefs.GetString("Email")) == 1)
       if(PlayerPrefs.HasKey("FaceRecognizedEmail"))
        {
            AlreadyAdded = true;
            FirstTimeFace = false;
            CameraClick = false;
            SignINPanel.SetActive(false);
            //CameraPanel.SetActive(true);
            StartFaceDetection = true;

            Debug.Log("Start Camera is Added Already.........................");
            CameraButtonClick(true);
            LoadingImageOfRecognizer.transform.parent.gameObject.SetActive(false);
            ToolBaar.SetActive(false);

            // AlreadyAdded = true;
            //TakePictureButton.gameObject.SetActive(true);

            //StartFaceDetection = true;
            //FirstTimeCheck();

            //TakePictureButton.gameObject.SetActive(false);
            //StartCheckFaceRecognization();

        }
/*        else
        {
            Debug.Log("Start Camera is not Added Already.........................");
            FirstTimeFace = true;
            AlreadyAdded = false;
            CameraClick = false;
            //StartFaceDetection = false;
            AddPerson.GetComponent<Button>().onClick.AddListener(() =>
            {
                WebCamTexture.OnAddPersonButtonClick();
                AddPersonButton();
            }

           
);


        }*/
/*        if (selectedCharacter == null)
        {
            selectedCharacter = this.gameObject.GetComponent<SelectedCharacter>();
        }*/
       // selectedCharacter.ShowSelectedCharacter();
        CongratsPanel.SetActive(false);
    }


    public void ShowSelectedCharacterInStart()
    {
        /*        if (selectedCharacter == null)
                {
                    selectedCharacter = this.gameObject.GetComponent<SelectedCharacter>();
                }*/
        //SaveCustomizeData.instance.ReadFirebaseData();
        selectedCharacter.ShowSelectedCharacter();
    }

    public void ShopButtonClick()
    {
        //_pageAnimScripObj.previousIndex=
        // _pageAnimScripObj.previousIndex = 3;

        _soundSriptObj.PlayButtonClickSound();
        ToolBarPanels.ToList().ForEach(g => g.SetActive(false));
        ToolBarPanels[1].gameObject.SetActive(true);
        taskBarButtonSprites.ToList().ForEach(g => g.SetActive(false));
        taskBarButtonSprites[1].SetActive(true);
        // _pageAnimScripObj.SetShopPanelAnim(3);
        CameraOff = true;
        AlreadyAddedButSignin = false;
       // FaceRecognizer.gameObject.SetActive(false);
    }
    public void MirrorButtonClick()
    {
        // _pageAnimScripObj.previousIndex = 1;
        _soundSriptObj.PlayButtonClickSound();
        ToolBarPanels.ToList().ForEach(g => g.SetActive(false));
        ToolBarPanels[3].gameObject.SetActive(true);
        taskBarButtonSprites.ToList().ForEach(g => g.SetActive(false));
        taskBarButtonSprites[3].SetActive(true);
        //_pageAnimScripObj.SetShopPanelAnim(1);
        //FaceRecognizer.gameObject.SetActive(false);
        //CameraPanel.SetActive(true);
        CameraOff = true;
    }
    public void ProfileButtonClick()
    {
        //_pageAnimScripObj.previousIndex = 4;
        _soundSriptObj.PlayButtonClickSound();
        ToolBarPanels.ToList().ForEach(g => g.SetActive(false));
        ToolBarPanels[0].gameObject.SetActive(true);
        taskBarButtonSprites.ToList().ForEach(g => g.SetActive(false));
        taskBarButtonSprites[0].SetActive(true);
        // _pageAnimScripObj.SetShopPanelAnim(4);
        //FaceRecognizer.gameObject.SetActive(false);
        CameraOff = true;
        //selectedCharacter.ShowSelectedCharacter();
    }
    public void CameraButtonClick(bool StartFaceRecognization)
    {
        /*        if (AlreadyAddedButSignin && CameraClick==false)
                {
                    ShopButtonClick();
                }
                else { */
        // _pageAnimScripObj.previousIndex = 2;
        _soundSriptObj.PlayButtonClickSound();

        CameraOff = false;
        FaceRecognizer.gameObject.SetActive(true);

        UseAnotherMethodToLoginButton.gameObject.SetActive(false);
        ToolBarPanels.ToList().ForEach(g => g.SetActive(false));
        ToolBarPanels[2].gameObject.SetActive(true);
        FaceRecognizer.gameObject.SetActive(true);
        taskBarButtonSprites.ToList().ForEach(g => g.SetActive(false));
        taskBarButtonSprites[2].SetActive(true);
        TopImagePanel.SetActive(true);
        // _pageAnimScripObj.SetShopPanelAnim(2);
        AddPerson.SetActive(true);
        /*        if (!OneTimePostAPI)
                {
                    CameraClick = true;
                }*/
        CameraClick = !StartFaceRecognization;
        if (CameraClick)
        {
            faceNotRegisteredtext.text = "";
        }
        if (StartFaceRecognization)
        {
            if (PlayerPrefs.HasKey("FaceRecognizedEmail"))
            {
                StartFaceDetection = false;
                LightSlider.gameObject.SetActive(false);
                AddPerson.gameObject.SetActive(false);
                UseAnotherMethodToLoginButton.gameObject.SetActive(true);
                TopImagePanel.transform.GetComponentInChildren<TMPro.TextMeshProUGUI>().text = "Your face is already registered! Please Keep Your Face in Front Of the Camera to continue. ";
            }

        }
        else
        {
            if (PlayerPrefs.HasKey("FaceRecognizedEmail"))
            {
                if (PlayerPrefs.GetString("FaceRecognizedEmail") == PlayerPrefs.GetString("Email"))
                {
                    UseAnotherMethodToLoginButton.gameObject.SetActive(false);
                    LightSlider.gameObject.SetActive(true);
                    AddPerson.GetComponentInChildren<Text>().text = "Face Added";
                    TopImagePanel.transform.GetComponentInChildren<TMPro.TextMeshProUGUI>().text = "Congratulations !" +
                                                        "Your Face is Already registered ";
                    AddPerson.GetComponent<Button>().interactable = false;
                }
                else
                {

                    AddPerson.GetComponent<Button>().onClick.AddListener(() =>
                    {
                        FaceOverrideOptionPanel();
                        //WebCamTexture.OnAddPersonButtonClick();
                        //AddPersonButton();
                    });
                    Debug.Log("Camera Panel is Called......................");
                    LightSlider.gameObject.SetActive(true);
                    AddPerson.GetComponentInChildren<Text>().text = "Add Face";
                    TopImagePanel.SetActive(true);
                    TopImagePanel.transform.GetComponentInChildren<TMPro.TextMeshProUGUI>().text = "Please register and add your face!";
                    AddPerson.GetComponent<Button>().interactable = true;
                }
            }
            else
            {
                AddPerson.GetComponent<Button>().onClick.AddListener(() =>
                {
                    //FaceOverrideOptionPanel();
                    WebCamTexture.OnAddPersonButtonClick();
                    AddPersonButton();
                });
                Debug.Log("Camera Panel is Called......................");
                LightSlider.gameObject.SetActive(true);
                AddPerson.GetComponentInChildren<Text>().text = "Add Face";
                TopImagePanel.SetActive(true);
                TopImagePanel.transform.GetComponentInChildren<TMPro.TextMeshProUGUI>().text = "Please register and add your face!";
                AddPerson.GetComponent<Button>().interactable = true;
            }
        }
    }
        /*if (AlreadyAdded)
        {
            TopImagePanel.SetActive(true);
            if (StartFaceDetection)
            {
                StartFaceDetection = false;
                LightSlider.gameObject.SetActive(false);
                AddPerson.gameObject.SetActive(false);
                UseAnotherMethodToLoginButton.gameObject.SetActive(true);
                TopImagePanel.transform.GetComponentInChildren<TMPro.TextMeshProUGUI>().text = "Your face is already registered! Please Keep Your Face in Front Of the Camera to continue. ";
            }
            else
            {
                UseAnotherMethodToLoginButton.gameObject.SetActive(false);
                LightSlider.gameObject.SetActive(true);
                AddPerson.GetComponentInChildren<Text>().text = "Face Added";
                TopImagePanel.transform.GetComponentInChildren<TMPro.TextMeshProUGUI>().text = "Congratulations !" +
                                                    "Your Face is Already registered ";
                AddPerson.GetComponent<Button>().interactable = false;
            }
            //AddPerson.GetComponentInChildren<Text>().text = "Face Added";



        }
        else
        {
            Debug.Log("Camera Panel is Called......................");
            LightSlider.gameObject.SetActive(true);
            AddPerson.GetComponentInChildren<Text>().text = "Add Face";
            TopImagePanel.SetActive(true);
            TopImagePanel.transform.GetComponentInChildren<TMPro.TextMeshProUGUI>().text = "Please register and add your face!";
            AddPerson.GetComponent<Button>().interactable = true;
        }
    }*/
    // }

    // BrightnessSliderImplementation(5f);

    public void ContentTypePassword(InputField field)
    {
        field.contentType = InputField.ContentType.Password;
        field.ActivateInputField();
    }
    public void ContentTypeStandard(InputField field)
    {
        field.contentType = InputField.ContentType.Standard;
        field.ActivateInputField();
    }

    public void SetToolbarPannels(GameObject PanelToBeActive)
    {
        ToolBarPanels.ToList().ForEach(g => g.SetActive(false));
        PanelToBeActive.SetActive(true);
    }

    /*    public void ToolBaarPanelEnable(int index)
        {
            if (index == (int)ToolBaarButton.CameraPanel)
            {
                Debug.Log("Camera Panel is Called......................");
                FaceRecognizer.SetActive(true);
                if(AlreadyAdded)
                {
                    LightSlider.gameObject.SetActive(true);
                    AddPerson.GetComponentInChildren<Text>().text = "Face Added";
                    TopImagePanel.SetActive(true);
                    AddPerson.GetComponent<Button>().interactable = false;
                }
                else
                {
                    Debug.Log("Camera Panel is Called......................");
                    LightSlider.gameObject.SetActive(true);
                    AddPerson.GetComponentInChildren<Text>().text = "Add Face";
                    TopImagePanel.SetActive(true);
                    AddPerson.GetComponent<Button>().interactable = true;
                }

            }
            else
            {
                FaceRecognizer.SetActive(false);
            }

            taskBarButtonSprites.ToList().ForEach(g => g.SetActive(false));
            ToolBarPanels.ToList().ForEach(g => g.SetActive(false));
            ToolBarPanels[index].gameObject.SetActive(true);
            taskBarButtonSprites[index].gameObject.SetActive(true);

            TaskBaarButton[index].onClick.Invoke();
        }
    */
    public void FaceOverrideOptionPanel()
    {
        
        if (PlayerPrefs.HasKey("FaceRecognizedEmail") )
        {
            AddPerson.GetComponent<Button>().onClick.RemoveAllListeners();
            FaceOverridePanel.gameObject.SetActive(true);
        }
        else
        {
            AddPersonButton();
            WebCamTexture.OnAddPersonButtonClick();
           

        }
    }
   public void FaceOverideOKButtonClick()
    {
        CameraClick = false;
        AddPerson.GetComponent<Button>().onClick.AddListener(() => {
            AddPersonButton();
            WebCamTexture.OnAddPersonButtonClick();
        });
        FaceOverridePanel.SetActive(false);
        
        AddPersonButton();
        WebCamTexture.OnAddPersonButtonClick();

    }
/*    public void FaceOverrideOptionCancelClick()
    {
        AddPerson.GetComponent<Button>().AddListener(()=> {
            AddPersonButton();
            WebCamTexture.OnAddPersonButtonClick();
            
        
        });
    }*/
    
    public void AddPersonButton()
    {
        FirstTimeFaceAddedComplete = true;
        _soundSriptObj.PlayButtonClickSound();
        //ToolBaar.gameObject.SetActive(false);
        LightSlider.gameObject.SetActive(false);
        AddPerson.gameObject.SetActive(false);
        LoadingImageOfRecognizer.transform.parent.gameObject.SetActive(true);
        ToolBaar.SetActive(false);
        CameraClick = false;

        /*        if (!AlreadyAdded)
                {
                    FaceRecognizer.gameObject.SetActive(true);
                    MainCamera.SetActive(false);
                    AddPerson.gameObject.SetActive(true);
                    CameraPanel.SetActive(false);
                    TextObjectToScann.SetActive(true);
                }
                else
                {
                    MainCamera.SetActive(true);
                    CameraPanel.SetActive(true);
                    ToolBaar.SetActive(true);
                    TakePictureButton.gameObject.SetActive(true);

                    //TakePictureButton.gameObject.SetActive(false);
                    TakePictureButton.GetComponentInChildren<UnityEngine.UI.Text>().text = "Already Face Added";
                    TakePictureButton.gameObject.GetComponent<Button>().interactable = false;
                    LoadingImageOfRecognizer.gameObject.transform.parent.gameObject.SetActive(false);
                    TextObjectToScann.SetActive(false);
                    new WaitForSeconds(10f);
                    FaceRecognizer.gameObject.SetActive(false);
                }*/

    }


    public void CheckUserJourney(bool FaceRegistered)
    {
        if (FaceRegistered)
        {
            ShopButtonClick();
        }
        else
        {
            CameraButtonClick(false);
        }
    }



/*    public void FirstTimeCheck()
    {
        if (PlayerPrefs.GetString("FaceRecognizedEmail") == PlayerPrefs.GetString("Email"))
        {

            AlreadyAdded = true;
            FirstTimeFace = false;
            //
            //CameraClick = false;
            SignINPanel.SetActive(false);
            //CameraPanel.SetActive(true);
            StartFaceDetection = true;
            CameraButtonClick();

            *//*            LightSlider.gameObject.SetActive(true);
                        AddPerson.GetComponentInChildren<Text>().text = "Face Added";
                        TopImagePanel.SetActive(true);
                        AddPerson.GetComponent<Button>().interactable = false;
                        FaceRecognizer.gameObject.SetActive(true);*//*
            // AddPerson.gameObject.SetActive(false);
            LoadingImageOfRecognizer.transform.parent.gameObject.SetActive(false);
            ToolBaar.SetActive(false);
            //TopImagePanel.gameObject.SetActive(false);
        }
        else
        {
            FirstTimeFace = true;
            AlreadyAdded = false;
            //CameraClick = false;
        }

    }*/


    class LoginForm
    {
        public string email;
        public string password;
    }


    public void LoginByFace()
    {
        if (!CameraClick && !FirstTimeFaceAddedComplete)
        {
            LoginForm obj = new LoginForm();
            if (PlayerPrefs.HasKey("FaceRecognizedEmail") && PlayerPrefs.HasKey("FaceRecognizedPassword"))
            {
                obj.email = PlayerPrefs.GetString("FaceRecognizedEmail");
                obj.password = PlayerPrefs.GetString("FaceRecognizedPassword");
                LogText.instance.tempMail = obj.email;
                LogText.instance.tempPassword = obj.password;
                StartCoroutine(APIHelper.PostRaw(JsonUtility.ToJson(obj), APIHelper.loginAdd, Authentication.instance.OnLoginEvent));
            }
            else
            {
                Debug.Log("PAssword and Email is NOt Saved");
            }
        }
        else if(FirstTimeFaceAddedComplete)
        {
            new WaitForSeconds(3f);
            CongratsPanel.SetActive(true);
            new WaitForSeconds(0.4f);
            CongratsAnimator.SetBool("CongratsAnim", true);
            Debug.Log("PopUp To TO Success Face Added................................................");
        }
        else
        {
            Debug.LogError("Do Nothing Login By Face");
        }
    }


/*    public void FaceLoginCompleted()
    {
        //MainCamera.SetActive(true);


        Debug.Log("Face Loggin Completed Now Work .///////////////////////////");
        if (!FirstTimeFace && AlreadyAdded && !CameraClick)
        {
            if (LogText.instance.CheckInternetConnection() == "1")
            {
                CameraOff = false;
                ToolBaar.SetActive(true);
                Debug.Log(" ./////////////////");
                LoginForm obj = new LoginForm();
                if (PlayerPrefs.HasKey("Email") && PlayerPrefs.HasKey("Password") && PlayerPrefs.HasKey("FaceRecognizedEmail"))
                {
                    if (OneTimePostAPI)
                    {
                        OneTimePostAPI = false;
                        obj.email = PlayerPrefs.GetString("FaceRecognizedEmail");
                        obj.password = PlayerPrefs.GetString("FaceRecognizedPassword");
                        LogText.instance.tempMail = obj.email;
                        LogText.instance.tempPassword = obj.password;
                        StartCoroutine(APIHelper.PostRaw(JsonUtility.ToJson(obj), APIHelper.loginAdd, Authentication.instance.OnLoginEvent));
                        Debug.Log(" .////////////////////");
                    }

                }

                //Authentication.instance.OnLoginEvent?.Invoke();

                // CameraPanel.gameObject.SetActive(false);
                //FaceRecognizer.gameObject.SetActive(false);
                //ShopButtonClick();
                Debug.Log(" .///////////////////////////");

            }
            else
            {
                LogText.instance.ShowLog("Please Check your Internet Connection");
            }

            //ToolBaarPanelEnable((int)ToolBaarButton.StorePanel);
            // AutomaticeClicked((int)ToolBaarButton.StorePanel);
        }
        else if (!CameraClick)
        {
            //CameraOff = true;
            //selectedCharacter.ShowSelectedCharacter();
            new WaitForSeconds(3f);
            CongratsPanel.SetActive(true);
            new WaitForSeconds(0.4f);
            CongratsAnimator.SetBool("CongratsAnim", true);
            Debug.Log("PopUp To TO Success Face Added................................................");


            //FirstTimeFaceLoginOKButton();


        }
        else 
        {
            Debug.Log(" .//////////////");
        }
*/
        /*else if (CameraClick)
    {
        CameraOff = false;
        FaceRecognizer.gameObject.SetActive(true);
    }*/
        //AlreadyAddedButSignin = false;
        //FaceRecognizer.gameObject.SetActive(false);
        /*        if (AlreadyAddedButSignin)
                {

                    CameraOff = true;
                    ToolBaar.SetActive(true);
                    ShopButtonClick();
                    return;
                }*/

  //  }


/*    public void FaceLoginByCamera()
    {
        if (!CameraClick && PlayerPrefs.HasKey("FaceRecognized"))
        {
            //CameraOff = false;
            ToolBaar.SetActive(true);
            Debug.Log(" ./////////////////");
            LoginForm obj = new LoginForm();
            if (PlayerPrefs.HasKey("Email") && PlayerPrefs.HasKey("Password") && PlayerPrefs.HasKey("FaceRecognizedEmail"))
            {
                    obj.email = PlayerPrefs.GetString("FaceRecognizedEmail");
                    obj.password = PlayerPrefs.GetString("FaceRecognizedPassword");
                    LogText.instance.tempMail = obj.email;
                    LogText.instance.tempPassword = obj.password;
                    StartCoroutine(APIHelper.PostRaw(JsonUtility.ToJson(obj), APIHelper.loginAdd, Authentication.instance.OnLoginEvent));
                    Debug.Log(" .////////////////////");
                

            }
        }
    }*/


    public void FirstTimeFaceLoginOKButton()
    {
        FirstTimeFaceAddedComplete = false;
        _soundSriptObj.PlayButtonClickSound();
        CongratsAnimator.SetBool("CongratsAnim", false);
        CameraOff = true;
        PlayerPrefs.SetString("FaceRecognizedEmail",PlayerPrefs.GetString("Email"));
        FirstTimeFace = false;
        AlreadyAdded = true;
        LoadingImageOfRecognizer.transform.parent.gameObject.SetActive(false);
        ToolBaar.SetActive(true);
        ProfileButtonClick();
        new WaitForSeconds(0.25f);
        CongratsPanel.SetActive(false);
        AvatarButtonAnim.SetBool("AvatarButtonFirstTime", true);
       // FaceRecognizer.gameObject.SetActive(false);
        //AutomaticeClicked((int)ToolBaarButton.HomePanel);
        //ToolBaarPanelEnable((int)ToolBaarButton.HomePanel);



    }
/*    public void AvatarFirstButtonClick()
    {
        _soundSriptObj.PlayButtonClickSound();
        AvatarButtonAnim.SetBool("AvatarButtonFirstTime", false);
    }*/
/*    public void OnSaveAvatarClicked()
    { }*/

/*    public void OnShowAvatarCustomzPanel()
    {
        avatarCustomzPanel.SetActive(true);

        UMAObjectRoot.SetActive(true);

        UMAModelMale.SetActive(true);
    }
*/

    public void BrightnessSliderImplementation(float sliderValue)
    {
        BrightnessLight.intensity = sliderValue;
    }


/*    public enum ToolBaarButton
    {
        HomePanel,
        StorePanel,
        CameraPanel,
        MirrorPanel

    }
*/
    public void UseAnotherMethodToLogin()
    {
        //AlreadyAddedButSignin = true;
        _soundSriptObj.PlayButtonClickSound();
        // _pageAnimScripObj.SetAnimSignInFromFacePanel();
        // new WaitForSeconds(20f);
        CameraOff = true;
        //FaceRecognizer.gameObject.SetActive(false);
        SignINPanel.SetActive(true);
        UseAnotherMethodToLoginButton.gameObject.SetActive(false);
        ToolBaar.SetActive(true);
        CameraPanel.SetActive(false);

    }

    public void LoadingPanelActivation(bool state)
    {
        LoadingPanel?.SetActive(state);
    }
    public void AlreadyAddSigningButtonCompelte()
    {
        /*        if (AlreadyAddedButSignin)
                {
                    // AlreadyAddedButSignin = false;
                    //FaceRecognizer.gameObject.SetActive(false);
                   // CameraPanel.gameObject.SetActive(false);
                    FaceLoginCompleted();
                }
                else
                {
                    //FaceRecognizer.gameObject.SetActive(false);           
                    //CameraPanel.gameObject.SetActive(false);
                    // CameraButtonClick();
                    if (!AlreadyAdded )
                    {
                        CameraButtonClick();
                    }
                }*/
    }
}



/*using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;
using System.IO;
public class UIManager : MonoBehaviour
{
    public static UIManager instance;
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
    }

    public GameObject[] taskBarButtonSprites;
    public GameObject[] ToolBarPanels;
    //public GameObject[] SelectedSprites;
    public Button[] TaskBaarButton;
    public GameObject clotheFullViewPanel;

    public GameObject avatarCustomzPanel;
    public GameObject UMAObjectRoot;
    public GameObject UMAModelMale;
    public GameObject UMAModelFeMale;
    public GameObject CameraPanel;

   // public GameObject MainCamera;
    public GameObject FaceRecognizer;
    public GameObject AddPerson;
    public bool AlreadyAdded = false;
   // public Button TakePictureButton;
    public GameObject LoadingImageOfRecognizer;
    public GameObject ToolBaar;
    public GameObject TopImagePanel;
    public GameObject SignINPanel;
    public GameObject TextObjectToScann;
    private bool FirstTimeFace = true;
    public bool CameraClick = false;
    public GameObject LightSlider;
    private SelectedCharacter selectedCharacter;
    public bool CameraOff = false;
    public GameObject CongratsPanel;
    public Animator CongratsAnimator;
    private bool StartFaceDetection =false;
    public Light BrightnessLight;
    public Animator AvatarButtonAnim;
    public GameObject UseAnotherMethodToLoginButton;
    public bool AlreadyAddedButSignin = false;
    public TMPro.TextMeshProUGUI faceNotRegisteredtext;



    // All Other Script Access Variable
    [Header("Other Scripts Variable To Access")]
    [SerializeField]
    private SoundScript _soundSriptObj;
    [SerializeField]
    private PageAnimation _pageAnimScripObj;
    private void Update()
    {
        // if (Input.GetKeyDown(KeyCode.Space))
        // {
        //     ShopManager.instance.GetCategory();
        //     ShopUI.instance.SetCategoryUI();
        // }
    }

    public void FaceIdKeyRemover()
    {
        PlayerPrefs.DeleteKey("FaceAddKey12");
    }


    public void Start()
    {
      if(_soundSriptObj==null) _soundSriptObj = FindObjectOfType<SoundScript>();
        if (_pageAnimScripObj == null) _pageAnimScripObj = FindObjectOfType<PageAnimation>();
        //PlayerPrefs.DeleteKey("FaceAddKey12");
        if (PlayerPrefs.GetInt("FaceAddKey12") == 1)
        {
            Debug.Log("Start Camera is Added Already.........................");
            // AlreadyAdded = true;
            //TakePictureButton.gameObject.SetActive(true);
            AlreadyAdded = true;
            FirstTimeFace = false;
            FirstTimeCheck();
            CameraClick = false;
            //TakePictureButton.gameObject.SetActive(false);
            //StartCheckFaceRecognization();

        }
        else
        {
            Debug.Log("Start Camera is not Added Already.........................");
            FirstTimeFace = true;
            AlreadyAdded = false;
        }
        if (selectedCharacter == null)
        {
            selectedCharacter =this.gameObject.GetComponent<SelectedCharacter>();
        }
        //selectedCharacter.ShowSelectedCharacter();
        CongratsPanel.SetActive(false);
    }
    public void ShopButtonClick()
    {
        //_pageAnimScripObj.previousIndex=
        // _pageAnimScripObj.previousIndex = 3;
       
        _soundSriptObj.PlayButtonClickSound();
        ToolBarPanels.ToList().ForEach(g => g.SetActive(false));
        ToolBarPanels[1].gameObject.SetActive(true);
        taskBarButtonSprites.ToList().ForEach(g => g.SetActive(false));
        taskBarButtonSprites[1].SetActive(true);
       // _pageAnimScripObj.SetShopPanelAnim(3);
        FaceRecognizer.gameObject.SetActive(false);
        CameraOff = true;
        AlreadyAddedButSignin = false;
    }
    public void MirrorButtonClick()
    {
       // _pageAnimScripObj.previousIndex = 1;
        _soundSriptObj.PlayButtonClickSound();
        ToolBarPanels.ToList().ForEach(g => g.SetActive(false));
        ToolBarPanels[3].gameObject.SetActive(true);
        taskBarButtonSprites.ToList().ForEach(g => g.SetActive(false));
        taskBarButtonSprites[3].SetActive(true);
        //_pageAnimScripObj.SetShopPanelAnim(1);
        FaceRecognizer.gameObject.SetActive(false);
        //CameraPanel.SetActive(true);
        CameraOff = true;
    }
    public void ProfileButtonClick()
    {
        //_pageAnimScripObj.previousIndex = 4;
        _soundSriptObj.PlayButtonClickSound();
        ToolBarPanels.ToList().ForEach(g => g.SetActive(false));
        ToolBarPanels[0].gameObject.SetActive(true);
        taskBarButtonSprites.ToList().ForEach(g => g.SetActive(false));
        taskBarButtonSprites[0].SetActive(true);
       // _pageAnimScripObj.SetShopPanelAnim(4);
        FaceRecognizer.gameObject.SetActive(false);      
        CameraOff = true;
        selectedCharacter.ShowSelectedCharacter();
    }
    public void CameraButtonClick()
    {
*//*        if (AlreadyAddedButSignin && CameraClick==false)
        {
            ShopButtonClick();
        }
        else { *//*
            // _pageAnimScripObj.previousIndex = 2;
            _soundSriptObj.PlayButtonClickSound();

            CameraOff = false;
        FaceRecognizer.gameObject.SetActive(true);

        UseAnotherMethodToLoginButton.gameObject.SetActive(false);
        ToolBarPanels.ToList().ForEach(g => g.SetActive(false));
        ToolBarPanels[2].gameObject.SetActive(true);
        FaceRecognizer.gameObject.SetActive(true);
        taskBarButtonSprites.ToList().ForEach(g => g.SetActive(false));
        taskBarButtonSprites[2].SetActive(true);
       // _pageAnimScripObj.SetShopPanelAnim(2);
        AddPerson.SetActive(true);
        CameraClick = true;
        if (CameraClick)
        {
            faceNotRegisteredtext.text = "";
        }

            if (AlreadyAdded)
        {
            TopImagePanel.SetActive(true);
            if (StartFaceDetection)
            {
                StartFaceDetection = false;
                LightSlider.gameObject.SetActive(false);
                AddPerson.gameObject.SetActive(false);
                UseAnotherMethodToLoginButton.gameObject.SetActive(true);
                TopImagePanel.transform.GetComponentInChildren<TMPro.TextMeshProUGUI>().text = "Your face is already registered! Please Keep Your Face in Front Of the Camera to continue. ";
            }
            else
            {
                UseAnotherMethodToLoginButton.gameObject.SetActive(false);
                LightSlider.gameObject.SetActive(true);
                AddPerson.GetComponentInChildren<Text>().text = "Face Added";
                TopImagePanel.transform.GetComponentInChildren<TMPro.TextMeshProUGUI>().text = "Congratulations !" +
                                                    "Your Face is Already registered ";
                AddPerson.GetComponent<Button>().interactable = false;
            }
            //AddPerson.GetComponentInChildren<Text>().text = "Face Added";
           
            
            
        }
        else
        {
            Debug.Log("Camera Panel is Called......................");
            LightSlider.gameObject.SetActive(true);
            AddPerson.GetComponentInChildren<Text>().text = "Add Face";
            TopImagePanel.SetActive(true);
            TopImagePanel.transform.GetComponentInChildren<TMPro.TextMeshProUGUI>().text = "Please register and add your face!";
            AddPerson.GetComponent<Button>().interactable = true;
        }
        }
   // }

    // BrightnessSliderImplementation(5f);

    public void ContentTypePassword(InputField field)
    {
        field.contentType = InputField.ContentType.Password;
        field.ActivateInputField();
    }
    public void ContentTypeStandard(InputField field)
    {
        field.contentType = InputField.ContentType.Standard;
        field.ActivateInputField();
    }

    public void SetToolbarPannels(GameObject PanelToBeActive)
    {
        ToolBarPanels.ToList().ForEach(g => g.SetActive(false));
        PanelToBeActive.SetActive(true);
    }

*//*    public void ToolBaarPanelEnable(int index)
    {
        if (index == (int)ToolBaarButton.CameraPanel)
        {
            Debug.Log("Camera Panel is Called......................");
            FaceRecognizer.SetActive(true);
            if(AlreadyAdded)
            {
                LightSlider.gameObject.SetActive(true);
                AddPerson.GetComponentInChildren<Text>().text = "Face Added";
                TopImagePanel.SetActive(true);
                AddPerson.GetComponent<Button>().interactable = false;
            }
            else
            {
                Debug.Log("Camera Panel is Called......................");
                LightSlider.gameObject.SetActive(true);
                AddPerson.GetComponentInChildren<Text>().text = "Add Face";
                TopImagePanel.SetActive(true);
                AddPerson.GetComponent<Button>().interactable = true;
            }

        }
        else
        {
            FaceRecognizer.SetActive(false);
        }
        
        taskBarButtonSprites.ToList().ForEach(g => g.SetActive(false));
        ToolBarPanels.ToList().ForEach(g => g.SetActive(false));
        ToolBarPanels[index].gameObject.SetActive(true);
        taskBarButtonSprites[index].gameObject.SetActive(true);
        
        TaskBaarButton[index].onClick.Invoke();
    }
*//*
    public void AddPersonButton()
    {
        _soundSriptObj.PlayButtonClickSound();
        //ToolBaar.gameObject.SetActive(false);
        LightSlider.gameObject.SetActive(false);
        AddPerson.gameObject.SetActive(false);
        LoadingImageOfRecognizer.transform.parent.gameObject.SetActive(true);
        ToolBaar.SetActive(false);
        CameraClick = false;

*//*        if (!AlreadyAdded)
        {
            FaceRecognizer.gameObject.SetActive(true);
            MainCamera.SetActive(false);
            AddPerson.gameObject.SetActive(true);
            CameraPanel.SetActive(false);
            TextObjectToScann.SetActive(true);
        }
        else
        {
            MainCamera.SetActive(true);
            CameraPanel.SetActive(true);
            ToolBaar.SetActive(true);
            TakePictureButton.gameObject.SetActive(true);
            
            //TakePictureButton.gameObject.SetActive(false);
            TakePictureButton.GetComponentInChildren<UnityEngine.UI.Text>().text = "Already Face Added";
            TakePictureButton.gameObject.GetComponent<Button>().interactable = false;
            LoadingImageOfRecognizer.gameObject.transform.parent.gameObject.SetActive(false);
            TextObjectToScann.SetActive(false);
            new WaitForSeconds(10f);
            FaceRecognizer.gameObject.SetActive(false);
        }*//*

    }

    public void FirstTimeCheck()
    {
        if (AlreadyAdded)
        {
            SignINPanel.SetActive(false);
            //CameraPanel.SetActive(true);
            StartFaceDetection = true;
            CameraButtonClick();

*//*            LightSlider.gameObject.SetActive(true);
            AddPerson.GetComponentInChildren<Text>().text = "Face Added";
            TopImagePanel.SetActive(true);
            AddPerson.GetComponent<Button>().interactable = false;
            FaceRecognizer.gameObject.SetActive(true);*//*
           // AddPerson.gameObject.SetActive(false);
            LoadingImageOfRecognizer.transform.parent.gameObject.SetActive(false);
            ToolBaar.SetActive(false);
            //TopImagePanel.gameObject.SetActive(false);
        }
        else
        {
            StartFaceDetection = false;
        }
    }

    *//*    public void AutomaticeClicked(int index)
        {

            TaskBaarButton[index].onClick.Invoke();

        }*/



/*    public void ToolBaarCameraClick()
    {
        CameraPanel.SetActive(true);
        FaceRecognizer.gameObject.SetActive(true);
        ToolBaar.gameObject.SetActive(true);
        LightSlider.gameObject.SetActive(true);
        LoadingImageOfRecognizer.transform.parent.gameObject.SetActive(false);
        if (AlreadyAdded)
        {

            TakePictureButton.gameObject.SetActive(true);
            TakePictureButton.GetComponentInChildren<UnityEngine.UI.Text>().text = "Face Added";
            TakePictureButton.gameObject.GetComponent<Button>().interactable = false;
        }
        else
        {
            TakePictureButton.gameObject.SetActive(true);
            TakePictureButton.gameObject.GetComponent<Button>().interactable = true;
            TakePictureButton.GetComponentInChildren<UnityEngine.UI.Text>().text = "Add Person";
        }

        //TakePictureButton.gameObject.SetActive(false);

    }*/
/*    public IEnumerator FaceRecognitionCompleted()
    {
        MainCamera.SetActive(true);
        CameraPanel.SetActive(true);
        ToolBaar.SetActive(true);
        TakePictureButton.gameObject.SetActive(false);
        LoadingImageOfRecognizer.gameObject.transform.parent.gameObject.SetActive(false);
        new WaitForSeconds(10f);
        FaceRecognizer.gameObject.SetActive(false);
        how to make quad on front of canvas in unity

    }*/
/*    public void StartCheckFaceRecognization()
    {
        SignINPanel.SetActive(false);
        //MainCamera.SetActive(false);
        //TakePictureButton.gameObject.SetActive(false);
        //AddPerson.gameObject.SetActive(false);
        CameraPanel.SetActive(true);
        LightSlider.SetActive(false);
        AddPerson.SetActive(false);
        ToolBaar.SetActive(false);
        new WaitForSeconds(3f);
        FaceRecognizer.gameObject.SetActive(true);
        FirstTimeFace = false;


    }*//*
class LoginForm
{
    public string email;
    public string password;
}
public void FaceLoginCompleted()
{
    //MainCamera.SetActive(true);


    Debug.Log("Face Loggin Completed Now Work .///////////////////////////");
    if (!FirstTimeFace && AlreadyAdded && !CameraClick)
    {
        if (LogText.instance.CheckInternetConnection() == "1")
        {
            CameraOff = false;
            ToolBaar.SetActive(true);
            if (!AlreadyAddedButSignin)
            {
                LoginForm obj = new LoginForm();
                if (PlayerPrefs.HasKey("Email") && PlayerPrefs.HasKey("Password"))
                {
                    obj.email = PlayerPrefs.GetString("Email");
                    obj.password = PlayerPrefs.GetString("Password");
                    LogText.instance.tempMail = obj.email;
                    LogText.instance.tempPassword = obj.password;
                    StartCoroutine(APIHelper.PostRaw(JsonUtility.ToJson(obj), APIHelper.loginAdd, Authentication.instance.OnLoginEvent));
                }

                //Authentication.instance.OnLoginEvent?.Invoke();
            }
            CameraPanel.gameObject.SetActive(false);
            FaceRecognizer.gameObject.SetActive(false);
            ShopButtonClick();
            Debug.Log(" .///////////////////////////");

        }
        else
        {
            LogText.instance.ShowLog("Please Check your Internet Connection");
        }

        //ToolBaarPanelEnable((int)ToolBaarButton.StorePanel);
        // AutomaticeClicked((int)ToolBaarButton.StorePanel);
    }
    else if(!CameraClick)
    {
        //CameraOff = true;
        //selectedCharacter.ShowSelectedCharacter();
        new WaitForSeconds(3f);
        CongratsPanel.SetActive(true);          
        new WaitForSeconds(0.4f);
        CongratsAnimator.SetBool("CongratsAnim", true);
        Debug.Log("PopUp To TO Success Face Added................................................");


        //FirstTimeFaceLoginOKButton();


    }else if (CameraClick)
    {
        CameraOff = false;
        FaceRecognizer.gameObject.SetActive(true);
    }
    //AlreadyAddedButSignin = false;
    //FaceRecognizer.gameObject.SetActive(false);
*//*        if (AlreadyAddedButSignin)
        {
            
            CameraOff = true;
            ToolBaar.SetActive(true);
            ShopButtonClick();
            return;
        }*//*

    }
    public void FirstTimeFaceLoginOKButton()
    {
        _soundSriptObj.PlayButtonClickSound();
        CongratsAnimator.SetBool("CongratsAnim", false);
        CameraOff = true;
        PlayerPrefs.SetInt("FaceAddKey12", 1);
        FirstTimeFace = false;
        AlreadyAdded = true;
        LoadingImageOfRecognizer.transform.parent.gameObject.SetActive(false);
        ToolBaar.SetActive(true);
        ProfileButtonClick();
        new WaitForSeconds(0.25f);
        CongratsPanel.SetActive(false);
        AvatarButtonAnim.SetBool("AvatarButtonFirstTime", true);
        FaceRecognizer.gameObject.SetActive(false);
        //AutomaticeClicked((int)ToolBaarButton.HomePanel);
        //ToolBaarPanelEnable((int)ToolBaarButton.HomePanel);



    }
    public void AvatarFirstButtonClick()
    {
        _soundSriptObj.PlayButtonClickSound();
        AvatarButtonAnim.SetBool("AvatarButtonFirstTime", false);
    }
    public void OnSaveAvatarClicked()
    { }

    public void OnShowAvatarCustomzPanel()
    {
        avatarCustomzPanel.SetActive(true);

        UMAObjectRoot.SetActive(true);

        UMAModelMale.SetActive(true);
    }


    public void BrightnessSliderImplementation(float sliderValue)
    {
        BrightnessLight.intensity = sliderValue;
    }


    public enum ToolBaarButton{
    HomePanel,
    StorePanel,
    CameraPanel,
    MirrorPanel

    }

    public void UseAnotherMethodToLogin()
    {
        AlreadyAddedButSignin = true;
        _soundSriptObj.PlayButtonClickSound();
       // _pageAnimScripObj.SetAnimSignInFromFacePanel();
       // new WaitForSeconds(20f);
        FaceRecognizer.gameObject.SetActive(false);
        SignINPanel.SetActive(true);
        UseAnotherMethodToLoginButton.gameObject.SetActive(false);
        ToolBaar.SetActive(true);
        CameraPanel.SetActive(false);
        
    }

    public void AlreadyAddSigningButtonCompelte()
    {
        if (AlreadyAddedButSignin)
        {
            // AlreadyAddedButSignin = false;
            //FaceRecognizer.gameObject.SetActive(false);
           // CameraPanel.gameObject.SetActive(false);
            FaceLoginCompleted();
        }
        else
        {
            //FaceRecognizer.gameObject.SetActive(false);           
            //CameraPanel.gameObject.SetActive(false);
            // CameraButtonClick();
            if (!AlreadyAdded )
            {
                CameraButtonClick();
            }
        }
    }
}
*/