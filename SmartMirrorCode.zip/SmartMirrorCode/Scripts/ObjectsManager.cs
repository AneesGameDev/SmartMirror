using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectsManager : MonoBehaviour
{
    public static ObjectsManager instance;
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
    }
    public SignupData.Root signupDataRoot;
    public UserData.Root userDataRoot;
    public ForgetData.Root forgetDataRoot;
    public LogError.Root logErrorRoot;
    public CategoryData.Root categroyDataRoot;
    public SubCategoryData.Root subCategoryRoot;
    public ClothesData.Root clothesDataRoot;
    public CartCheckoutData.Root cartCheckoutRoot; 
    public ClotheDetailsData.Root clotheDetailsData;
    public AllOderData.Root allOderData; 

}
