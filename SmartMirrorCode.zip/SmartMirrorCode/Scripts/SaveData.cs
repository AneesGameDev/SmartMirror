using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;

public static class SaveData
{
    static string fileName = "CartData";
    public static void SaveIntoJson<T>(T t)
    {
        string potion = JsonUtility.ToJson(t);
        File.WriteAllText(Application.persistentDataPath + "/CartData.json", potion);
    }
}
public static class LoadData
{
    static string fileName = "CartData";
    public static void LoadIntoJson()
    {
        var json=File.ReadAllText(Application.persistentDataPath + "/CartData.json");
        ShopManager.instance.cartdata=JsonUtility.FromJson<CartDataLocal.Root>(json);
    }
}
[Serializable]
public class CartDataLocal
{
    [Serializable]
    public class Cart
    {
        // public Cart(string _name, string _price)
        // {
        //     name = _name;
        //     price = _price;
        // }
        public int id;
        public string name;
        public string price;
    }
    [Serializable]
    public class Root
    {
        public List<Cart> CartData = new List<Cart>();
    }
}