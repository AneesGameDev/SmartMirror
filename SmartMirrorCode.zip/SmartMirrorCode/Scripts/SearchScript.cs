using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;


public class SearchScript : MonoBehaviour , ISelectHandler ,IDeselectHandler
{
    public InputField SearchInputField;
    private UnityEvent OnSearchCall;
    public bool OnSelectBool = false;
    public int previousSearchLength;
    

    // Start is called before the first frame update
    void Start()
    {
/*        OnSearchCall.AddListener(() =>
        {
            SearchField();
        });*/
       // SearchInputField.onValueChanged.AddListener(  SearchField );
    }

    public void SearchField(string text)
    {
        /*        if(SearchInputField.characterValidation == InputField.CharacterValidation.Alphanumeric)
                {*/
        /*        if(SearchInputField.textComponent.text.Contains("  "))
                {
                    LogText.instance.ShowLog("Please remove double space in search field");
                }
                else
                {
                    ShopManager.instance.GetClotheSearch(SearchInputField.textComponent);
                }*/
        SearchValidation();
       // }
/*        else
        {
            ShopManager.instance.SearchReback();
        }*/
        
    }
    // Update is called once per frame
    void Update()
    {
        if (OnSelectBool)
        {
            if (string.IsNullOrWhiteSpace(SearchInputField.textComponent.text))
            {
                OnSelectBool = false;
                ShopManager.instance.SearchReback();
               
            }
        }
      
/*            if (previousSearchLength != SearchInputField.textComponent.text.Length)
            {
            previousSearchLength = SearchInputField.textComponent.text.Length;
            SearchValidation();
                
            }*/

/*            if (SearchInputField.textComponent.text.Length != 0)
            {

            }
            if (SearchInputField.textComponent.text == "" || SearchInputField.textComponent.text == " ")
            {
                ShopManager.instance.SearchReback();


            }
            else
            {
                ShopManager.instance.GetClotheSearch(SearchInputField.textComponent);
            }*/
        
    }


    public void SearchValidation()
    {

        if (string.IsNullOrWhiteSpace(SearchInputField.textComponent.text))
        {
            Debug.Log("Search Do Nothing");
            ShopManager.instance.SearchReback();
        }
        else
        {
            ShopManager.instance.GetClotheSearch(SearchInputField.textComponent);
        }
    }

    private void OnDestroy()
    {
        SearchInputField.onValueChanged.RemoveAllListeners();
    }

    public void OnSelect(BaseEventData eventData)
    {
        //throw new System.NotImplementedException();
        OnSelectBool = true;
    }

    public void OnDeselect(BaseEventData eventData)
    {
        //OnSelectBool = false;
        //throw new System.NotImplementedException();
        //ShopManager.instance.SearchReback();
    }
}
