using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class ClotheComponent : MonoBehaviour
{
    public ClothesData.Clothe clothe;
    public TMP_Text _name,disTxt;
    public Image img;
    public TMP_Text price;
    public TMP_Text discount;
    public TMP_Text orignalPrice;
    public void OnButtonClick()
    {
        SoundScript.instance.PlayButtonClickSound();
        UIManager.instance.clotheFullViewPanel.SetActive(true);
        ClotheFullViewComponent.instance.clothe=clothe;
        ClotheFullViewComponent.instance.SetUIData();
    }
}
