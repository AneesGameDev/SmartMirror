using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LogText : MonoBehaviour
{
    public GameObject logObject;
    public static LogText instance;
    public static string Email =null, Password = null;
    public static string Age = null, Gender = null;
    public string tempMail, tempPassword;
    public static int FaceRecognition = 0;
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        // This iEmail and Passwork is Set only if User is Face Recognized 
        if (PlayerPrefs.HasKey("Email") && PlayerPrefs.HasKey("Password"))
        {
            Email = PlayerPrefs.GetString("Email");
            Password = PlayerPrefs.GetString("Password");
            tempMail = Email;
            tempPassword = Password;
            Debug.Log("Emails is" + Email);
            Debug.Log("Password is" + Password);        }
    }
    public Text logText;
    public void ShowLog(string log)
    {
        logObject.SetActive(true);
        logText.text = log;
        Invoke(nameof(ResetLog), 2);
    }
    void ResetLog()
    {
        logText.text = "";
        logObject.SetActive(false);
    }

 
    public string CheckInternetConnection()
    {
        bool internetPossiblyAvailable;
/*        switch (Application.internetReachability)
        {
            case NetworkReachability.ReachableViaLocalAreaNetwork:
                internetPossiblyAvailable = true;
                break;
            case NetworkReachability.ReachableViaCarrierDataNetwork:
                internetPossiblyAvailable = false;
                break;
            default:
                internetPossiblyAvailable = false;
                break;
        }
        Debug.Log("Internet Connection is" + internetPossiblyAvailable);
        if (!internetPossiblyAvailable)
        {
            //InternetIsNotAvailable();
            return "0"; //Internet is not available
        }
        else
        {
            return "1";  //internet is available
        }*/

        if(Application.internetReachability == NetworkReachability.NotReachable)
        {
            return "0";
        }
        else
        {
            return "1";
        }
        //ping = new Ping(pingAddress);
        //pingStartTime = Time.time;
    }


}

