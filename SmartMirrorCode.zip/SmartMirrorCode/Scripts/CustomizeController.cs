using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UMA;
using UMA.CharacterSystem;
using UMA.CharacterSystem.Examples;
using UnityEngine.UI;
using TMPro;

public class CustomizeController : MonoBehaviour
{
    private string[] _colors = { "#E8BEAC", "#826355", "#F1DEB0", "#BF9171", "#FFDBAC", "#654A32" };
    private float[] _valuesInput;
   // public GameObject CustomizePanel1, CustomizePanel2;
    private SelectedCharacter _selectedAvatar;
   //[HideInInspector]
    
    private Dictionary<string, DnaSetter> _dna;
    private SaveCustomizeData _saveData;
    public Slider[] sliders;
    public Slider[] MeasurementSlider;
    public TextMeshProUGUI[] DisplaySloderText;
    public TextMeshProUGUI ShirtSizeText, PantSizeText;
    //  public TMP_InputField[] TMPInputFields;
    public TMP_Dropdown ChestDropDown , WaistDropDown , ArmLengthDropDown, HeightDropDown, LegsHeightDropDown , LegsWidthDropDown;
    private float _chestMin = 10, _chestMax =1, _waistMin =10, _waistMax = 1, _armMin = 4, _armMax = 0.48f, _legHeightMin =14,
        _legHeightMax =0.63f, _legWidthMin =10, _legWidthMax =1f, _heightMin=4, _heightMax =0.63f;
    public float difference;
    public float ration;
    private float _prevArmLength, _prevHeight, _prevLagLength;
    [Header("Avatar Reference")]
    public DynamicCharacterAvatar _avatar;
    
    // Start is called before the first frame update
    private void Awake()
    {
        
    }

    private void OnEnable()
    {
        //_avatar.CharacterDnaUpdated.AddListener(GetDna);
        _avatar.CharacterUpdated.AddListener(GetDna);
        
    }
    private void OnDisable()
    {
        _avatar.CharacterUpdated.RemoveListener(GetDna);
    }

    void Start()
    {
      // _valuesInput = new float[TMPInputFields.Length];
        _selectedAvatar = FindObjectOfType<SelectedCharacter>();
       //_avatar = _selectedAvatar._dynamicCharacterAvatar;
        _saveData = FindObjectOfType<SaveCustomizeData>();
/*        SetDropDownMenuInInches(ChestDropDown, _chestMin, _chestMax);
        SetDropDownMenuInInches(WaistDropDown, _waistMin, _waistMax);
        SetDropDownMenuInInches(ArmLengthDropDown, _armMin, _armMax);
        SetDropDownMenuInInches(LegsHeightDropDown, _legHeightMin, _legHeightMax);
        SetDropDownMenuInInches(LegsWidthDropDown, _legWidthMin, _legWidthMax);
        SetDropDownMenuInFeet(HeightDropDown, _heightMin, _heightMax);*/
    }


    public void SetDropDownMenuInInches(TMP_Dropdown DropDown , int min , int max )
    {
        List<TMP_Dropdown.OptionData> options = new List<TMP_Dropdown.OptionData>();
        for (int i = min; i <= max; i++)
        {
            TMP_Dropdown.OptionData item = new TMP_Dropdown.OptionData();
            item.text = i + "";
            options.Add(item);
        }
        DropDown.AddOptions(options);
    }

    public void SetDropDownMenuInFeet(TMP_Dropdown DropDown, int min, int max)
    {
        List<TMP_Dropdown.OptionData> options = new List<TMP_Dropdown.OptionData>();
        for (int i = min; i <= max; i++)
        {
            for(int y =1; y<=9; y++)
            {
                TMP_Dropdown.OptionData item = new TMP_Dropdown.OptionData();
                item.text = i + "'"+y;
                options.Add(item);
            }
           
        }
        DropDown.AddOptions(options);
    }

    public void ApplyChanges()
    {
/*        float chestCurrent = MathValueClampCustomInt( _chestMax ,0 , 1 , ChestDropDown ,false);
        float waistCurrent = MathValueClampCustomInt(_waistMax, 0 ,1, WaistDropDown, false);
        float armLengthCurrent = MathValueClampCustomInt(_armMax, 0, 0.8f, ArmLengthDropDown, true);
        float legsHeightCurrent = MathValueClampCustomInt(_legHeightMax, 0, 0.63f, LegsHeightDropDown, true);
        float legsWidthCurrent = MathValueClampCustomInt(_legWidthMax, 0, 1, LegsWidthDropDown, false);
        float HeightCurrent = MathValueClampCustomInt(_heightMax, 0, 0.63f, HeightDropDown, true);*/
       
    }
    public float MathValueClampCustomInt(int max ,float limitMin, float limitMax , TMP_Dropdown dropDown ,bool CheckLimit)
    {
        float currentValue;
        if (dropDown.transform.GetChild(0).gameObject.GetComponent<TextMeshProUGUI>().text.Contains("'"))
        {
            string text = dropDown.transform.GetChild(0).gameObject.GetComponent<TextMeshProUGUI>().text.Replace("'",".");
            float.TryParse(text,out currentValue);

        }
        else
        {
            float.TryParse(dropDown.transform.GetChild(0).gameObject.GetComponent<TextMeshProUGUI>().text, out currentValue);
        }
        
        //difference = max - min;
        ration = limitMax / max;
        float ValueTOReturn= currentValue * ration;
        if (CheckLimit)
        {
            if(ValueTOReturn > limitMax)
            {
                ValueTOReturn = limitMax;
            }
        }
        return ValueTOReturn;

       //return ValueTOReturn;
    }

/*    private void OnEnable()
    {
        //_avatar = _selectedAvatar._dynamicCharacterAvatar;
        
        // 
    }*/

    public void GetAvatarButton()
    {
       // _avatar = null;
        StartCoroutine(GetAvatar());

    }
    public IEnumerator GetAvatar()
    {

/*        while (_avatar == null)
        {
            *//*            if (_selectedAvatar._characterSelection == 0)
                        {
                            _avatar = _selectedAvatar._dynamicCharactermaleAvatar;
                        }
                        else if (_selectedAvatar._characterSelection == 1)
                        {
                            _avatar = _selectedAvatar._dynamicCharacterfemaleAvatar;
                        }*//*
           // _avatar = _selectedAvatar._dynamicCharactermaleAvatar;
            yield return null;
        }*/
        _avatar.SetColor("Eyes", ConvertHexToColor(_saveData.dataObj._eyeColor));
        _avatar.SetColor("Hair", ConvertHexToColor(_saveData.dataObj._hairColor));
        _avatar.SetColor("Skin", ConvertHexToColor(_saveData.dataObj._skinColor));

        _avatar.BuildCharacter();
        //GetDna();
        yield return new WaitForSeconds(1f);



/*
        if (_selectedAvatar._characterSelection == 0)
        {
            _avatar = _selectedAvatar._dynamicCharactermaleAvatar;
        }
        else if (_selectedAvatar._characterSelection == 1)
        {
            _avatar = _selectedAvatar._dynamicCharacterfemaleAvatar;
        }*/




    }
    public void GetDna(UMAData data)
    {

            _dna = _avatar.GetDNA();
          //  yield return null;

        //Debug.Log("DNA Value IS " + _dna["headSize"].Value);
      /*  sliders[0].value = _saveData.dataObj._shoulderValue;
        sliders[1].value = _saveData.dataObj._chestValue;
        sliders[2].value = _saveData.dataObj._waistValue;
        sliders[3].value = _saveData.dataObj._hipsValue;
        sliders[4].value = _saveData.dataObj._thighsValue;*/

        //FOrm DaN Data SLiders Start Value
        if (_saveData.dataObj._HeightFormValue <= 0.1f)
        {
            _saveData.dataObj._chestFormValue = 0.5f;
            _saveData.dataObj._waistFormValue = 0.5f;
            _saveData.dataObj._armLengthFormValue = 0.5f;
            _saveData.dataObj._HeightFormValue = 0.5f;
            _saveData.dataObj._legsLengthFormValue = 0.5f;
            _saveData.dataObj._legsLengthFormValue = 0.5f;
        }
        MeasurementSlider[0].value = (MeasurementSlider[0].maxValue / _chestMax) * _saveData.dataObj._chestFormValue;//==0 ? 0.5f : _saveData.dataObj._chestFormValue;
        MeasurementSlider[1].value = (MeasurementSlider[1].maxValue / _waistMax) * _saveData.dataObj._waistFormValue;//==0?0.5f : _saveData.dataObj._waistFormValue;
        MeasurementSlider[2].value = (MeasurementSlider[2].maxValue / _armMax) * _saveData.dataObj._armLengthFormValue; //==0? 0.5f: _saveData.dataObj._armLengthFormValue;
        Debug.Log("Heigh Form Value is ..........." + _saveData.dataObj._HeightFormValue);
        MeasurementSlider[3].value = (MeasurementSlider[3].maxValue / _heightMax) * _saveData.dataObj._HeightFormValue;// == 0 ? 0.5f : _saveData.dataObj._HeightFormValue;
        MeasurementSlider[4].value = (MeasurementSlider[4].maxValue / _legHeightMax) * _saveData.dataObj._legsLengthFormValue; //== 0 ? 0.5f : _saveData.dataObj._legsLengthFormValue;
        MeasurementSlider[5].value = (MeasurementSlider[5].maxValue / _legWidthMax) * _saveData.dataObj._legsWidthFormValue;//== 0 ? 0.5f : _saveData.dataObj._legsWidthFormValue;
        for(int i= 0; i <= 5; i++)
        {
            MeasurementSlider[i].GetComponent<SliderButtonScript>().DoubleColorSliderMethod();
        }
        GetAvatarButton();
        _avatar.BuildCharacter();
        if (SelectedCharacter.FirstTime)
        {

            SelectedCharacter.FirstTime = false;
            _selectedAvatar.DisableActivatedCharacter();
           

        }

        // yield return new WaitForSeconds(1f);
    }
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            _avatar.SetColor("Skin", Color.green);
            _avatar.BuildCharacter();
        }

       //if (_dna == null) _dna = _avatar.GetDNA();

    }

   public void ChangeEyeColor(int id)
    {
        /*CheckValidateForm();
        CustomizeManualForm(InputValueRange(_valuesInput[0],30 , 40), InputValueRange(_valuesInput[1], 22, 44), InputValueRange(_valuesInput[0], 24, 48),
            InputValueRange(_valuesInput[0], 24, 48), InputValueRange(_valuesInput[0], 24, 48));*/
        _avatar?.SetColor("Eyes", ConvertHexToColor(_colors[id]));
        _avatar.BuildCharacter();
        _saveData.dataObj._eyeColor = _colors[id];
    }
    public void ChangeSkinColor(int id)
    {
        _avatar?.SetColor("Skin", ConvertHexToColor(_colors[id]));
        _avatar.BuildCharacter();
        _saveData.dataObj._skinColor = _colors[id];
    }
    public void ChangeHairColor(int id)
    {
        
        _avatar?.SetColor("Hair", ConvertHexToColor(_colors[id]));
        _avatar.BuildCharacter();
        _saveData.dataObj._hairColor = _colors[id];
    }
    private Color ConvertHexToColor(string Hex)
    {
        Color color;
        ColorUtility.TryParseHtmlString(Hex, out color);
        return color;
            
    }
/*    public void ChangeShouldersSlider(float value)
    {
        _dna["upperMuscle"].Set(value);
        _avatar.BuildCharacter();
        _saveData.dataObj._shoulderValue = value;

    }*/
/*    public void ChangeChestSlider(float value)
    {
        _dna["breastSize"].Set(value);
        _avatar.BuildCharacter();
        _saveData.dataObj._chestValue = value;

    }*/
/*    public void ChangeWaistSlider(float value)
    {
        _dna["waist"].Set(value);
        _avatar.BuildCharacter();
        _saveData.dataObj._waistValue = value;
    }*/
/*    public void ChangeHipsSlider(float value)
    {
        _dna["legSeparation"].Set(value);
        _avatar.BuildCharacter();
        _saveData.dataObj._hipsValue = value;

    }*/
    
/*    public void ChangeThighsSlider(float value)
    {
        _dna["lowerWeight"].Set(value);
        _avatar.BuildCharacter();
        _saveData.dataObj._thighsValue = value;
    }
*/
    private void CheckValidateForm()
    {
       /* for(int i=0; i<TMPInputFields.Length; i++)
        {
            if (float.TryParse(TMPInputFields[i].text, out _valuesInput[i]))
            {
                Debug.Log("Input is Converted Into FLoat");
            }else
            {
                Debug.Log("Input Does Not Convert into Float");

            }
            }*/
 /*      for(int i=0; i<5; i++)
        {
            DropDown.options = new List<TMP_Dropdown.OptionData>();
        }*/
        }

    public void ChangeChestFormSLider(float value )
    {
        ration = _chestMax/MeasurementSlider[0].maxValue;
         difference = value * ration;
        DisplaySloderText[0].text = (int)value + "";
        _dna["upperMuscle"].Set(difference);
        _avatar.BuildCharacter();
        _saveData.dataObj._chestFormValue = difference;
        _saveData.dataObj._ChestInInches =(int) value;
        _saveData.dataObj.ShirtEnum = _saveData.ShirtsInStandardSize(this.ShirtSizeText);
    }
    public void ChangeWaistFormSLider(float value)
    {
        float ration = _waistMax / MeasurementSlider[1].maxValue;
        float difference = value * ration;
        DisplaySloderText[1].text = (int)value + "";
        _dna["waist"].Set(difference);
        _dna["belly"].Set(difference);
        _avatar.BuildCharacter();
        _saveData.dataObj._waistFormValue = difference;
        _saveData.dataObj._WaistInInches = (int)value;
        _saveData.dataObj.ShirtEnum = _saveData.ShirtsInStandardSize(this.ShirtSizeText);
    }
    public void ChangeArmlengthFormSLider(float value)
    {   
        if (value < 12) value = 12;
        MeasurementSlider[2].value = value;
        float ration = _armMax / MeasurementSlider[2].maxValue;
        float difference = value * ration;
        DisplaySloderText[2].text = (int)value + "";
       // if (difference > 0.5f)
        {
            _dna["armLength"].Set(difference);
            _avatar.BuildCharacter();
            _saveData.dataObj._armLengthFormValue = difference;
        }
        Debug.Log("Difference Of Length is " + value);
        if(_prevArmLength>=value-1 && _prevArmLength <= value + 1)
        {
            return;
        }
        else
        {
            
            float tempHeight = 2 + (6 - (MeasurementSlider[2].maxValue - value)) * 0.83f;
            _prevArmLength = value;
            ChangeHeightFormSLider(tempHeight);
        }
       
    }
    public void ChangeHeightFormSLider(float value)
    {
        MeasurementSlider[3].value = value;
        float ration = _heightMax / MeasurementSlider[3].maxValue;
        float difference = value * ration;
        DisplaySloderText[3].text = Mathf.Abs(value) + "";
        _dna["height"].Set(difference);
        _avatar.BuildCharacter();
        _saveData.dataObj._HeightFormValue = difference;
        // int ValueInInches = (int) (value * 12);
        //_saveData.dataObj.HeightInInches = ValueInInches;
        
        if(_prevHeight >= value-1f && _prevHeight <= value + 1f)
        {
            return;
        }
        else
        {
            float templegLength = value;
            _prevHeight = value;
            ChangeLegLengthtFormSLider(templegLength * 6.8f);
        }
        
    }
    public void ChangeLegLengthtFormSLider(float value)
    {
        MeasurementSlider[4].value = value;
        float ration = _legHeightMax / MeasurementSlider[4].maxValue;
        float difference = value * ration;
        DisplaySloderText[4].text = (int)value + "";
        _dna["legsSize"].Set(difference);
        _avatar.BuildCharacter();
        _saveData.dataObj._legsLengthFormValue = difference;
        _saveData.dataObj.HeightInInches = (int)value;
        _saveData.dataObj.PantEnum = _saveData.PantsInStandardSize(this.PantSizeText);
        if(_prevLagLength >= value-2 && _prevLagLength <=value+2)
        {
            return;
        }
        else
        {
            float tempLength = (value / 6.8f) + 10f;
            _prevLagLength = value;
            ChangeArmlengthFormSLider(tempLength);
        }

    }
    public void ChangeLegWidthFormSLider(float value)
    {
        float ration = _legWidthMax / MeasurementSlider[5].maxValue;
        float difference = value * ration;
        DisplaySloderText[5].text = (int)value + "";
        _dna["lowerWeight"].Set(difference);
        _avatar.BuildCharacter();
        _saveData.dataObj._legsWidthFormValue = difference;
        _saveData.dataObj.HipWidthInInches = (int)value;
        _saveData.dataObj.PantEnum = _saveData.PantsInStandardSize(this.PantSizeText);
    }
    public void CustomizeManualForm(float chest  , float waist , float legs, float armlength, float height)
    {
        Debug.Log("     Legs      " + legs + "    ArmLength     " + armlength + "      Chest     " + chest + "     Waist  " + waist + "     Height   " + height);

    }
     float InputValueRange(float value , float min , float max)
    {
        if (value < min)
        {
            return min;
        }else if(value > max)
        {
            return max;
        }
        else
        {
            return value;
        }
    }


/*    public void ActiveDeactivateCustomizePanel(TextMeshProUGUI text)
    {
        if (CustomizePanel1.activeSelf)
        {
            CustomizePanel1.SetActive(false);
            CustomizePanel2.SetActive(true);
            text.text = "Customize";

        }
        else
        {

            CustomizePanel2.SetActive(false);
            CustomizePanel1.SetActive(true);
            text.text = "Measurements";
        }
    }*/

    public void SliderChnagePlusButton(Slider currentSlider )
    {
        currentSlider.value += 1f;
    }
    public void SliderChnageMinusButton(Slider currentSlider)
    {
        currentSlider.value -= 1f;
    }

}