using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using Firebase;
using Firebase.Extensions;
using Firebase.Storage;
using System;
using Firebase.Database;
using System.Threading.Tasks;



public enum StandardName
{
    Small,
    Medium,
    Large,
    ExtraLarge
}
public class GarmentsSize
{
    
}

[Serializable]
public class CustomizeData
{   
    public string _eyeColor;
    public string _hairColor;
    public string _skinColor;/*
    public float _shoulderValue;
    public float _chestValue;
    public float _waistValue;
    public float _hipsValue;
    public float _thighsValue;*/
    public bool male;
    //Value Of Customization Form is Below...............
    public float _chestFormValue;
    public float _legsWidthFormValue;
    public float _waistFormValue;
    public float _HeightFormValue;
    public float _legsLengthFormValue;
    public float _armLengthFormValue;
    public int _ChestInInches;
    public int _WaistInInches;
    public int HipWidthInInches;
    public int HeightInInches;
    

    public StandardName ShirtEnum = StandardName.Medium, PantEnum = StandardName.Medium;
   // public StandardName MansShirt = StandardName.Medium, MansPant = StandardName.Medium;


}

public class SaveCustomizeData : MonoBehaviour
{
    private CustomizeController customizeController;
    StorageReference uploadRef;
    [SerializeField]
    //private Authentication authentication;
    public CustomizeData dataObj = new CustomizeData();
    private string _path;
    public static SaveCustomizeData instance;
    /*
        FirebaseStorage storage;
        StorageReference storageReference;*/
    DatabaseReference reference;

    private void Awake()
    {
        if (instance = null)
        {
            instance = this;
        }
       // _path = Application.persistentDataPath + "/CharacterCustomizeData.mirror";

    }

    // Start is called before the first frame update
    private void OnEnable()
    {

    }
    void Start()
    {
       
        customizeController = FindObjectOfType<CustomizeController>();
        //reference = FirebaseDatabase.DefaultInstance.GetReferenceFromUrl("https://sm-app-366617-default-rtdb.firebaseio.com/");
        // reference = FirebaseDatabase.DefaultInstance.RootReference;
        reference = FirebaseDatabase.DefaultInstance.RootReference;
        // authentication = authentication ? FindObjectOfType<Authentication>() : authentication;
        //storage = FirebaseStorage.DefaultInstance;
        // storageReference = storage.GetReferenceFromUrl("gs://sm-app-366617.appspot.com/");
        //LoadData();
    }


    /*    public void UploadJsonClick()
        {
            ShowLoadDialogCoroutine();

        }*/

    /*    void UploadJsonData(string JsonObj)
        {


            //string JsonData = JsonUtility.ToJson(JsonObj);
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(JsonObj);
            //Editing Metadata
            var newMetadata = new MetadataChange();
            newMetadata.ContentType = "json";

            //Create a reference to where the file needs to be uploaded
            StorageReference uploadRef = storageReference.Child("Custom/CustomizeCharacter.json");
            Debug.Log("File upload started");
            uploadRef.PutBytesAsync(bytes, newMetadata).ContinueWithOnMainThread((task) =>
            {
                if (task.IsFaulted || task.IsCanceled)
                {
                    LogText.instance.ShowLog("Try Again ! Data Not Saved");
                    Debug.Log(task.Exception.ToString());
                }
                else
                {
                    LogText.instance.ShowLog("Saved Successfully");
                    Debug.Log("File Uploaded Successfully");
                }

            }
           );
            *//*            uploadRef.PutBytesAsync(bytes, newMetadata).ContinueWithOnMainThread((task) => {
                            if (task.IsFaulted || task.IsCanceled)
                            {
                                Debug.Log(task.Exception.ToString());
                            }
                            else
                            {
                                Debug.Log("File Uploaded Successfully!");
                            }
                        });*//*


        }

    */

    public void SaveDataMethod()
    {
        SaveData();
    }
    // Update is called once per frame
    void Update()
    {

    }
    public void SaveData()
    {
        reference = FirebaseDatabase.DefaultInstance.RootReference;
        if (LogText.instance.CheckInternetConnection() == "1")
        {

                string JsonData = JsonUtility.ToJson(dataObj);
               // File.WriteAllText(_path, JsonData);
                // UploadJsonData(JsonData);
                FirebaseDataBaseAddUser(JsonData);
                //ReadFirebaseData();
         
        }
        else
        {
            LogText.instance.ShowLog("Check Your Internet Connection");
        }

    }

    public void SetUserDataBAse()
    {
        writeNewUser("13331", "Anees", "@temp.com");
    }

    public void writeNewUser(string userId, string name, string email)
    {
        User user = new User(name, email);
        string json = JsonUtility.ToJson(user);

        reference.Child("users").Child(userId).SetRawJsonValueAsync(json);
    }
    public void FirebaseDataBaseAddUser(string json)
    {
        if (reference != null)
        {
            string UserMail = LogText.Email;
            UserMail.Replace(".com", "");
            
            Debug.Log(UserMail.Replace(".com",""));
           Task task= reference.Child("users").Child(UserMail.Replace(".com", "")).SetRawJsonValueAsync(json).ContinueWith(task =>
            {
                // task.GetAwaiter().IsCompleted;
                //object obj = task.IsCompleted;
               //  WaitUntil(obj);
                Debug.Log("Task Complete Succesdsfully");


                if (task.IsFaulted)
                {
                    LogText.instance.ShowLog("Try Again ! Data Not Saved");
                    Debug.Log("fireabase Data Not Added Successfully");
                }
                else
                {
                    LogText.instance.ShowLog("Saved Successfully");
                }

            });
            
            if (task.IsFaulted)
            {
                LogText.instance.ShowLog("Try Again ! Data Not Saved");
                Debug.Log("fireabase Data Not Added Successfully");
            }
            else
            {
                Debug.Log("Task Completed Successfully");
                LogText.instance.ShowLog("Saved Successfully");
            }

           // task.Wait();
           // dataObj = JsonUtility.FromJson<CustomizeData>(reference.Child("users").Child(UserMail.Replace(".com", "")).GetValueAsync());
            //reference.Child("users").Child(LogText.instance.tempMail).SetRawJsonValueAsync(json);
        }
        else
        {
            Debug.Log("Null Reference Found");
        }

    }
    public void ReadFirebaseData()
    {
        string UserMail = LogText.Email;
        
        reference.Child("users").Child(UserMail.Replace(".com", "")).GetValueAsync().ContinueWith(task =>
        {
            if (task.IsCompleted)
            {
                Debug.Log("Data Fetched Successfully");
                //dataObj = task.Result;
                DataSnapshot data = task.Result;
                if (data.Value != null)
                {
                    Debug.Log("Data OD Database" + data);
                    DataSnapToJsonSetter(data);
                }
                else
                {
                    InitializeFirebaseData();
                }

                //dataObj = JsonUtility.FromJson<CustomizeData>(data);
            }
            else
            {
                Debug.Log("Task Not COmplete");
            }
        });
    }

    public void DataSnapToJsonSetter(DataSnapshot data)
    {

        string json = data.GetRawJsonValue();
        Debug.Log(json);
        dataObj = JsonUtility.FromJson<CustomizeData>(json);
        Debug.Log(dataObj.HeightInInches);
/*        dataObj._eyeColor = data.Child("_eyeColor").Value.ToString();
        dataObj._hairColor = data.Child("_hairColor").Value.ToString();
        dataObj._skinColor = data.Child("_skinColor").Value.ToString();
        dataObj.PantEnum = (StandardName)data.Child("PantEnum").Value;
        dataObj.ShirtEnum = (StandardName)data.Child("ShirtEnum").Value;
        dataObj.male = (bool)data.Child("male").Value;
        //Value Of Customization Form is Below...............
        dataObj._chestFormValue = (float)data.Child("_chestFormValue").Value;
        dataObj._legsWidthFormValue = (float)data.Child("_legsWidthFormValue").Value;
        dataObj._waistFormValue = (float)data.Child("_waistFormValue").Value;
        dataObj._HeightFormValue = (float)data.Child("_HeightFormValue").Value;
        dataObj._legsLengthFormValue = (float)data.Child("_legsLengthFormValue").Value;
        dataObj._armLengthFormValue = (float)data.Child("_armLengthFormValue").Value;
        dataObj._ChestInInches = (int)data.Child("_ChestInInches").Value;
        dataObj._WaistInInches = (int)data.Child("_WaistInInches").Value;
        dataObj.HipWidthInInches = (int)data.Child("HipWidthInInches").Value;
        dataObj.HeightInInches = (int)data.Child("HeightInInches").Value;
        Debug.Log("Height Get IS....................." + dataObj.HeightInInches);*/
    }



/*private void LoadData()
    {
        if (File.Exists(_path))
        {
            string DataFile = File.ReadAllText(_path);
            dataObj = JsonUtility.FromJson<CustomizeData>(DataFile);
        }
        else
        {
            InitializeData();
            string JsonData = JsonUtility.ToJson(dataObj);
            File.WriteAllText(_path, JsonData);
        }
    }*/
    public void InitializeFirebaseData()
    {
        InitializeData();
        string json = JsonUtility.ToJson(dataObj);
        //customizeController.GetAvatarButton();
        FirebaseDataBaseAddUser(json);
    }
    void InitializeData()
    {

        dataObj._eyeColor = "#0000000";
        dataObj._hairColor = "#0000000";
        dataObj._skinColor = "#F1DEB0";

        dataObj.PantEnum = StandardName.Medium;
        dataObj.ShirtEnum = StandardName.Medium;
        /*      dataObj.MansPant = StandardName.Medium;
                dataObj.MansShirt = StandardName.Medium;*/

        dataObj._chestFormValue = 0.5f;
        dataObj._legsWidthFormValue = 0.7f;
        dataObj._waistFormValue = 0.6f;
        dataObj._HeightFormValue = 0.43f;
        dataObj._legsLengthFormValue = 0.4f;
        dataObj._armLengthFormValue = 0.45f;
        dataObj._ChestInInches = 30;
        dataObj._WaistInInches = 36;
        dataObj.HeightInInches = 60;
        dataObj.HipWidthInInches = 31;


    }



    public StandardName ShirtsInStandardSize(TMPro.TextMeshProUGUI ShirtText)
    {
        StandardName ShirtEnum = StandardName.Medium;
        if (!dataObj.male)
        {

            if (dataObj._ChestInInches > 0 && dataObj._ChestInInches <= 35 || dataObj._WaistInInches > 0 && dataObj._WaistInInches <= 27)
            {
                if (dataObj._ChestInInches > 35)
                {
                    // Second Else IF COndition is Run Form Here
                    // ShirtEnum = StandardName.Medium;
                    ShirtEnum = WomenChestSizeByValue(dataObj._ChestInInches);
                }
                else if (dataObj._WaistInInches > 27)
                {
                    ShirtEnum = WomenWaistSizeByValue(dataObj._WaistInInches);
                }
                else
                {
                    ShirtEnum = StandardName.Small;
                }

            }
            else if (dataObj._ChestInInches > 35 && dataObj._ChestInInches <= 38 || dataObj._WaistInInches > 27 && dataObj._WaistInInches <= 31)
            {
                if (dataObj._ChestInInches > 38)
                {
                    // Second Else IF COndition is Run Form Here
                    //    ShirtEnum = StandardName.Medium;
                    ShirtEnum = WomenChestSizeByValue(dataObj._ChestInInches);
                }
                else if (dataObj._WaistInInches > 31)
                {
                    ShirtEnum = WomenWaistSizeByValue(dataObj._WaistInInches);
                }
                else
                {
                    ShirtEnum = StandardName.Medium;
                }

            }
            else if (dataObj._ChestInInches > 38 && dataObj._ChestInInches <= 43 || dataObj._WaistInInches > 31 && dataObj._WaistInInches <= 36)
            {
                if (dataObj._ChestInInches > 43)
                {
                    // Second Else IF COndition is Run Form Here
                    //    ShirtEnum = StandardName.Medium;
                    ShirtEnum = WomenChestSizeByValue(dataObj._ChestInInches);
                }
                else if (dataObj._WaistInInches > 36)
                {
                    ShirtEnum = WomenWaistSizeByValue(dataObj._WaistInInches);
                }
                else
                {
                    ShirtEnum = StandardName.Large;
                }

            }
            else
            {
                ShirtEnum = StandardName.ExtraLarge;
                // Extra Large Size is Here Display
            }
            ShirtText.text = SizeTextReturn(ShirtEnum);

            Debug.Log("Womens Shirts Size is Waist is =" + dataObj._WaistInInches + "Chest is Inches =" + dataObj._ChestInInches + "and Medium is =" + ShirtEnum);
        }
        else
        {


            if (dataObj._ChestInInches > 0 && dataObj._ChestInInches <= 37 || dataObj._WaistInInches > 0 && dataObj._WaistInInches <= 31)
            {
                if (dataObj._ChestInInches > 37)
                {
                    // Second Else IF COndition is Run Form Here
                    // ShirtEnum = StandardName.Medium;
                    ShirtEnum = MensChestSizeByValue(dataObj._ChestInInches);
                }
                else if (dataObj._WaistInInches > 31)
                {
                    ShirtEnum = MensWaistSizeByValue(dataObj._WaistInInches);
                }
                else
                {
                    ShirtEnum = StandardName.Small;
                }

            }
            else if (dataObj._ChestInInches > 37 && dataObj._ChestInInches <= 40 || dataObj._WaistInInches > 31 && dataObj._WaistInInches <= 34)
            {
                if (dataObj._ChestInInches > 40)
                {
                    // Second Else IF COndition is Run Form Here
                    //    ShirtEnum = StandardName.Medium;
                    ShirtEnum = MensChestSizeByValue(dataObj._ChestInInches);
                }
                else if (dataObj._WaistInInches > 34)
                {
                    ShirtEnum = MensWaistSizeByValue(dataObj._WaistInInches);
                }
                else
                {
                    ShirtEnum = StandardName.Medium;
                }

            }
            else if (dataObj._ChestInInches > 40 && dataObj._ChestInInches <= 44 || dataObj._WaistInInches > 34 && dataObj._WaistInInches <= 37)
            {
                if (dataObj._ChestInInches > 44)
                {
                    // Second Else IF COndition is Run Form Here
                    //    ShirtEnum = StandardName.Medium;
                    ShirtEnum = MensChestSizeByValue(dataObj._ChestInInches);
                }
                else if (dataObj._WaistInInches > 37)
                {
                    ShirtEnum = MensWaistSizeByValue(dataObj._WaistInInches);
                }
                else
                {
                    ShirtEnum = StandardName.Large;
                }

            }
            else
            {
                ShirtEnum = StandardName.ExtraLarge;
                // Extra Large Size is Here Display
            }

            ShirtText.text = SizeTextReturn(ShirtEnum);
            //Debug.Log("Mans Shirts Size is Waist is =" + dataObj._WaistInInches + "Chest is Inches =" + dataObj._ChestInInches + "and Medium is =" + ShirtEnum);


        }


        return ShirtEnum;
    }



    public StandardName PantsInStandardSize(TMPro.TextMeshProUGUI PantText)
    {
        StandardName WomenPants = StandardName.Medium;

        if (!dataObj.male)
        {

            if (dataObj.HeightInInches > 0 && dataObj.HeightInInches <= 29 || dataObj.HipWidthInInches > 0 && dataObj.HipWidthInInches <= 35)
            {
                if (dataObj.HeightInInches > 29)
                {
                    // Second Else IF COndition is Run Form Here
                    //    ShirtEnum = StandardName.Medium;
                    WomenPants = WomenHeightSizeByValue(dataObj.HeightInInches);
                }
                else if (dataObj.HipWidthInInches > 35)
                {
                    WomenPants = WomenHipsSizeByValue(dataObj.HipWidthInInches);
                }
                else
                {
                    WomenPants = StandardName.Small;
                }

            }
            else if (dataObj.HeightInInches > 29 && dataObj.HeightInInches <= 31 || dataObj.HipWidthInInches > 37 && dataObj.HipWidthInInches <= 38)
            {
                if (dataObj.HeightInInches > 31)
                {
                    // Second Else IF COndition is Run Form Here
                    //    ShirtEnum = StandardName.Medium;
                    WomenPants = WomenHeightSizeByValue(dataObj.HeightInInches);
                }
                else if (dataObj.HipWidthInInches > 38)
                {
                    WomenPants = WomenHipsSizeByValue(dataObj.HipWidthInInches);
                }
                else
                {
                    WomenPants = StandardName.Medium;
                }

            }
            else if (dataObj.HeightInInches > 31 && dataObj.HeightInInches <= 34 || dataObj.HipWidthInInches > 40 && dataObj.HipWidthInInches <= 40)
            {
                if (dataObj.HeightInInches > 34)
                {
                    // Second Else IF COndition is Run Form Here
                    //    ShirtEnum = StandardName.Medium;
                    WomenPants = WomenHeightSizeByValue(dataObj.HeightInInches);
                }
                else if (dataObj._WaistInInches > 40)
                {
                    WomenPants = WomenHipsSizeByValue(dataObj.HipWidthInInches);
                }
                else
                {
                    WomenPants = StandardName.Large;
                }

            }
            else
            {
                WomenPants = StandardName.ExtraLarge;
                // Extra Large Size is Here Display
            }

            Debug.Log("Womens Height is =" + dataObj.HeightInInches + "Hips is =" + dataObj.HipWidthInInches + "and Medium is =" + WomenPants);
            PantText.text = SizeTextReturn(WomenPants);

        }
        else
        {
            if (dataObj.HeightInInches > 0 && dataObj.HeightInInches <= 31 || dataObj.HipWidthInInches > 0 && dataObj.HipWidthInInches <= 40)
            {
                if (dataObj.HeightInInches > 31)
                {
                    // Second Else IF COndition is Run Form Here
                    //    ShirtEnum = StandardName.Medium;
                    WomenPants = MensHeightSizeByValue(dataObj.HeightInInches);
                }
                else if (dataObj.HipWidthInInches > 40)
                {
                    WomenPants = MensHipsSizeByValue(dataObj.HipWidthInInches);
                }
                else
                {
                    WomenPants = StandardName.Small;
                }

            }
            else if (dataObj.HeightInInches > 31 && dataObj.HeightInInches <= 34 || dataObj.HipWidthInInches > 40 && dataObj.HipWidthInInches <= 42)
            {
                if (dataObj.HeightInInches > 34)
                {
                    // Second Else IF COndition is Run Form Here
                    // ShirtEnum = StandardName.Medium;
                    WomenPants = MensHeightSizeByValue(dataObj.HeightInInches);
                }
                else if (dataObj.HipWidthInInches > 42)
                {
                    WomenPants = MensHipsSizeByValue(dataObj.HipWidthInInches);
                }
                else
                {
                    WomenPants = StandardName.Medium;
                }

            }
            else if (dataObj.HeightInInches > 34 && dataObj.HeightInInches <= 37 || dataObj.HipWidthInInches > 40 && dataObj.HipWidthInInches <= 43)
            {
                if (dataObj.HeightInInches > 37)
                {
                    // Second Else IF COndition is Run Form Here
                    //    ShirtEnum = StandardName.Medium;
                    WomenPants = MensHeightSizeByValue(dataObj.HeightInInches);
                }
                else if (dataObj._WaistInInches > 43)
                {
                    WomenPants = MensHipsSizeByValue(dataObj.HipWidthInInches);
                }
                else
                {
                    WomenPants = StandardName.Large;
                }

            }
            else
            {
                WomenPants = StandardName.ExtraLarge;
                // Extra Large Size is Here Display
            }

            //Debug.Log("Mens Height is =" + dataObj.HeightInInches + "Hips is =" + dataObj.HipWidthInInches + "and Medium is =" + WomenPants);
            PantText.text = SizeTextReturn(WomenPants);
        }



        return WomenPants;
    }


    public string SizeTextReturn(StandardName name)
    {
        string Text = "";

        switch (name)
        {
            case StandardName.Small: return "S";

            case StandardName.Medium: return "M";

            case StandardName.Large: return "L";

            case StandardName.ExtraLarge: return "XL";


        }

        return Text;
    }




    public StandardName WomenChestSizeByValue(int value)
    {

        if (value <= 35)
        {
            return StandardName.Small;
        }
        else if (value <= 38)
        {
            return StandardName.Medium;
        }
        else if (value <= 43)
        {
            return StandardName.Large;
        }
        else
        {
            return StandardName.ExtraLarge;
        }
    }
    public StandardName WomenWaistSizeByValue(int value)
    {
        if (value <= 27)
        {
            return StandardName.Small;
        }
        else if (value <= 31)
        {
            return StandardName.Medium;
        }
        else if (value <= 36)
        {
            return StandardName.Large;
        }
        else
        {
            return StandardName.ExtraLarge;
        }
    }
    public StandardName WomenHipsSizeByValue(int value)
    {

        if (value <= 35)
        {
            return StandardName.Small;
        }
        else if (value <= 38)
        {
            return StandardName.Medium;
        }
        else if (value <= 40)
        {
            return StandardName.Large;
        }
        else
        {
            return StandardName.ExtraLarge;
        }
    }
    public StandardName WomenHeightSizeByValue(int value)
    {
        if (value <= 29)
        {
            return StandardName.Small;
        }
        else if (value <= 31)
        {
            return StandardName.Medium;
        }
        else if (value <= 34)
        {
            return StandardName.Large;
        }
        else
        {
            return StandardName.ExtraLarge;
        }
    }



    public StandardName MensChestSizeByValue(int value)
    {
        if (value <= 37)
        {
            return StandardName.Small;
        }
        else if (value <= 40)
        {
            return StandardName.Medium;
        }
        else if (value <= 44)
        {
            return StandardName.Large;
        }
        else
        {
            return StandardName.ExtraLarge;
        }

    }
    public StandardName MensWaistSizeByValue(int value)
    {
        if (value <= 31)
        {
            return StandardName.Small;
        }
        else if (value <= 34)
        {
            return StandardName.Medium;
        }
        else if (value <= 37)
        {
            return StandardName.Large;
        }
        else
        {
            return StandardName.ExtraLarge;
        }

    }
    public StandardName MensHipsSizeByValue(int value)
    {
        if (value <= 40)
        {
            return StandardName.Small;
        }
        else if (value <= 42)
        {
            return StandardName.Medium;
        }
        else if (value <= 43)
        {
            return StandardName.Large;
        }
        else
        {
            return StandardName.ExtraLarge;
        }
    }

    public StandardName MensHeightSizeByValue(int value)
    {
        if (value <= 31)
        {
            return StandardName.Small;
        }
        else if (value <= 34)
        {
            return StandardName.Medium;
        }
        else if (value <= 37)
        {
            return StandardName.Large;
        }
        else
        {
            return StandardName.ExtraLarge;
        }
    }

    /*    int CompareWithRange(int firstMin , int firstMax , int secondMin , int secondMax , int CurrentFirstValue , int CurrentSecondValue)
        {
            int Value=0;
            float Ratio1 = 1/(firstMax-firstMin);
            float Ratio2 = 1 / (secondMax - secondMin);

            Ratio1 = Ratio1 * CurrentFirstValue;
            Ratio2 = Ratio2 * CurrentSecondValue;

            if (Ratio1 > Ratio2)
            {
                Value = 1;
            }
            else
            {
                Value = 2;
            }
            return Value;
        }*/

    public class User
    {
        public string username;
        public string email;

        public User()
        {
        }

        public User(string username, string email)
        {
            this.username = username;
            this.email = email;
        }

    }
}
