using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class DropSownDataSettere : MonoBehaviour
{
    public TMP_Dropdown AgeYearDropDown;
    public TMP_Dropdown GenderDropDown;
    public TextMeshProUGUI AgeLableText;
    public TextMeshProUGUI GenderLabelText;
   // public TMP_Text AgelLable , GenderLable;
    private int StartYear = 2015;
    List<TMP_Dropdown.OptionData> listOption = new List<TMP_Dropdown.OptionData>();
    //List<string> YearList = new List<string>();
    // Start is called before the first frame update
    void Start()
    {
        //AgeYearDropDown.onValueChanged.AddListener(Dro);
        ///AgelLable.text = "Year Of Birth";
        //GenderLable.text = "Gender";
        AgeYearDropDown.ClearOptions();
        
        for(int i=0; i<90; i++)
        {
            TMP_Dropdown.OptionData item = new TMP_Dropdown.OptionData();
            StartYear--;
            //YearList.Add("" + StartYear);
            item.text = ""+StartYear;
            listOption.Add(item);
            //AgeYearDropDown.options.Add(listOption);
        }
        AgeYearDropDown.AddOptions(listOption);
        AgeLableText.text = "Date Of Birth";
        GenderLabelText.text = "Gender";
        //Debug.Log("Age Value"+AgeYearDropDown.captionText.text);
        //AgeYearDropDown.GetComponent<TMP_Dropdown>().captionText= AgelLable;
        //AgeYearDropDown.GetComponent<TMP_Dropdown>().captionText = GenderLable;


    }
    public void DropDownAgeData(TMP_Text LableText)
    {
        Debug.Log(LableText.text);
    }

    public void DropDownGenderData(TMP_Text GenderText)
    {
        Debug.Log(GenderText.text);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
