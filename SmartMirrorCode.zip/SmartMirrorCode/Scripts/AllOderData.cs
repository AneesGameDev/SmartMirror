using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
public class AllOderData
{
    [Serializable]
    public class ClotheDetails
    {
        public int id;
        public string title;
        public int categoryId;
        public int subCategoryId;
        public string description;
        public string price;
        public object image;
        public DateTime createdAt;
        public DateTime updatedAt;
    }
    [Serializable]

    public class ClotheSize
    {
        public int id;
        public int clotheId;
        public int sizeId;
        public int quantity;
        public DateTime createdAt;
        public DateTime updatedAt;
        public ClotheDetails clotheDetails;
    }
    [Serializable]

    public class Data
    {
        public List<Order> orders;
    }
    [Serializable]

    public class Order
    {
        public int id;
        public int orderId;
        public int userId;
        public string status;
        public string totalAmount;
        public DateTime createdAt;
        public DateTime updatedAt;
        public List<OrderDetail> orderDetails;
    }
    [Serializable]

    public class OrderDetail
    {
        public int id;
        public int sizeId;
        public string quantity;
        public string price;
        public string orderId;
        public DateTime createdAt;
        public DateTime updatedAt;
        public ClotheSize clotheSize;
    }
    [Serializable]

    public class Root
    {
        public string status;
        public bool error;
        public Data data;
    }


}
