using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIInitializer : MonoBehaviour
{
    public Text HomePanelProfileText;
    public static UIInitializer instance;
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ProfileTextSetter(string ProfileName)
    {
        if (ProfileName != "")
        {
            HomePanelProfileText.text = ProfileName;
        }
        else
        {
            Debug.LogError("Profile Name is Null");
        }
    }
}
