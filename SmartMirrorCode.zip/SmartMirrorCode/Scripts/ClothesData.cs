using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[Serializable]
public class ClothesData : MonoBehaviour
{

[Serializable]
   
    public class Category
    {
        public int id ;
        public string name ;
        public DateTime createdAt ;
        public DateTime updatedAt ;
    }
[Serializable]

    public class Clothe
    {
        public int id ;
        public string title ;
        public int categoryId ;
        public int subCategoryId ;
        public string description ;
        public string price ;
        public string image ;
        public int discountInPercentage ;
        public DateTime createdAt ;
        public DateTime updatedAt ;
        public List<Review> Reviews ;
        public List<ClotheSize> clotheSizes ;
        public Category category ;
        public SubCategory subCategory ;
    }
[Serializable]

    public class ClotheSize
    {
        public int id ;
        public int clotheId ;
        public int sizeId ;
        public int quantity ;
        public DateTime createdAt ;
        public DateTime updatedAt ;
        public Sizes sizes ;
    }
[Serializable]

    public class Data
    {
        public List<Clothe> clothes ;
    }
[Serializable]

    public class Review
    {
        public int id ;
        public int clotheId ;
        public int userId ;
        public int review ;
        public object description ;
        public DateTime createdAt ;
        public DateTime updatedAt ;
    }
[Serializable]

    public class Root
    {
        public string status ;
        public bool error ;
        public Data data ;
    }
[Serializable]

    public class Sizes
    {
        public string name ;
    }
[Serializable]

    public class SubCategory
    {
        public int id ;
        public string name ;
        public int categoryId ;
        public object brandName ;
        public string img ;
        public DateTime createdAt ;
        public DateTime updatedAt ;
    }


}
