using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CategoryComponent : MonoBehaviour
{
    public void OnButtonClick()
    {
        ShopManager.instance.GetSubCategory(id);
    }
    public int id;
    public Text _name;
}
