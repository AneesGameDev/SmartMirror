using System.Threading;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Events;
using UnityEngine.UI;
using ZXing;
using ZXing.QrCode;
using System.Threading.Tasks;

public class QRScanner : MonoBehaviour
{
    public bool isCamAvailable;
    public RawImage rawImageBackground;
    public AspectRatioFitter aspectRatioFitter;
    public Text textOut;
    public RectTransform scanZone;
    public WebCamTexture cameraTexture;
    public Button scanButton, openLinkButton;
    public Sprite scanFailed, scan, scanSucceed;
    public void BackButtonClick()
    {
        GameManager.instance.shopPanel.SetActive(true);
        SceneManager.UnloadSceneAsync("scan");
    }

    private void Start()
    {
        scanButton.onClick.AddListener(() => OnClickScan());
        scanButton.onClick.AddListener(() => OnClickScan());
        SetUpCamera();;
    }
    private void Update()
    {
        UpdateCameraRender();
        if (Input.GetMouseButtonDown(0))
        {
            cameraTexture.autoFocusPoint = Vector2.zero;
        }
    }
    public int totalDevices = 0;
    public int currentDevice = 0;
    public WebCamDevice[] devices;
    public void SetUpCamera()
    {
        devices = WebCamTexture.devices;
        totalDevices = devices.Length;
        if (devices.Length == 0)
        {
            isCamAvailable = false;
            return;
        }
        for (int i = 0; i < devices.Length; i++)
        {
            cameraTexture = new WebCamTexture(devices[i].name, (int)scanZone.rect.width, (int)scanZone.rect.height);
        }
        cameraTexture.Play();
        rawImageBackground.texture = cameraTexture;
        isCamAvailable = true;
    }
    public void ChangeCameraClick()
    {
        if (devices.Length == 0)
        {
            isCamAvailable = false;
            return;
        }
        currentDevice++;
        if (currentDevice > totalDevices - 1)
        {
            currentDevice = 0;
        }
        cameraTexture = new WebCamTexture(devices[currentDevice].name, (int)scanZone.rect.width, (int)scanZone.rect.height);
        cameraTexture.Play();
        rawImageBackground.texture = cameraTexture;
        isCamAvailable = true;

    }
    public void UpdateCameraRender()
    {
        if (!isCamAvailable)
        {
            return;
        }
        float ratio = (float)cameraTexture.width / (float)cameraTexture.height;
        aspectRatioFitter.aspectRatio = ratio;
        int oriantation = -cameraTexture.videoRotationAngle;
        rawImageBackground.rectTransform.localEulerAngles = new Vector3(0, 0, oriantation);
    }
    public void OnClickScan()
    {
        scanButton.image.sprite = scan;
        Scan();
    }
    void Scan()
    {
        try
        {
            IBarcodeReader barcodeReader = new BarcodeReader();
            Result result = barcodeReader.Decode(cameraTexture.GetPixels32(), cameraTexture.width, cameraTexture.height);
            if (result != null)
            {
                textOut.text = result.Text;
                openLinkButton.interactable = true;
                scanButton.image.sprite = scanSucceed;
                OpenLinkButton();
               // Bluetooth.Instance().Connect(result.Text);
            }
            else
            {
                openLinkButton.interactable = false;
                textOut.text = "QR scanning failed";
                scanButton.image.sprite = scanFailed;
                if (myCancelTokenSource != null)
                {
                    myCancelTokenSource.Cancel();
                }
                myCancelTokenSource.Dispose();
                myCancelTokenSource = new CancellationTokenSource();
                BackToScan();
            }
        }
        catch
        {
            openLinkButton.interactable = false;
            scanButton.image.sprite = scanFailed;
            textOut.text = "failed In Try";
            if (myCancelTokenSource != null)
            {
                myCancelTokenSource.Cancel();
            }
            myCancelTokenSource.Dispose();
            myCancelTokenSource = new CancellationTokenSource();
            BackToScan();
        }
    }
    CancellationTokenSource myCancelTokenSource = new CancellationTokenSource();
    public async void BackToScan()
    {
        //Task t;
        try
        {
            await Task.Delay(3000, myCancelTokenSource.Token);
            if (!myCancelTokenSource.Token.IsCancellationRequested)
            {
                textOut.text = "Tap to Scan";
                scanButton.image.sprite = scan;
            }
        }
        catch (System.Exception)
        {
        }
        // Thread.Sleep(2000);
        //await myTask;
    }
    public void OpenLinkButton()
    {
        Application.OpenURL(textOut.text);
    }
}
