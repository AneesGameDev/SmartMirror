﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using UnityEngine.SceneManagement;

public class BounceBackUIAnimation : MonoBehaviour
{
    [SerializeField] GameObject[] ButtonsToShake;
    public float animationTime =0.2f;
    // Start is called before the first frame update
    void OnEnable()
    {
        StartCoroutine(ShowButtons());
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public IEnumerator ShowButtons()
    {
        // LeanTween.scale(ButtonsToShake[i], new Vector3(0f, 0f, 0f), 0).setEaseOutBack();
        HideButtons();
        animationTime = 0.3f;
        for (int i = 0; i < ButtonsToShake.Length; i++)
        {
            yield return new WaitForSeconds(animationTime);
            //if(SoundManager.sharedSoundManager())
            //SoundManager.sharedSoundManager().playButtonTapMusic();
            //if (LoadingHandler.Instance)
            //    LoadingHandler.Instance.PlayTapSound();
            LeanTween.scale(ButtonsToShake[i], new Vector3(1f, 1f, 1f), animationTime).setEaseOutBack();
            
        }
        yield return new WaitForSeconds(animationTime);
       /* if(LoadingHandler.Instance)
        LeanTween.scale(LoadingHandler.Instance.playButton, new Vector2(0.9f, 0.9f), 0.5f).setLoopPingPong(-1);*/
    }
    public void HideButtons()
    {
        for (int i = 0; i < ButtonsToShake.Length; i++)
        {
           // ButtonsToShake[i].SetActive(false);
            LeanTween.scale(ButtonsToShake[i], new Vector3(0f, 0f, 0f), 0).setEaseOutBack();
        }
    }
    void OnDisable()
    {
        HideButtons();
    }
}
