using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
public class ShopUI : MonoBehaviour
{
    public static ShopUI instance;
    public Color selectedColor;

    public Text totalCartPriceTxt, itemTxt, itemPriceTxt;
    public static int total = 0;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
    }
    // clothe data 
    public ClotheComponent clothePrefab;
    // category data 
    public CategoryComponent categoryPrefab;
    public Transform categoryBar;
    // subcategory data 
    public SubcategoryComponent subcategoryPrefab;
    public ScrollRect highlightScroll, brandScroll, newArivalScroll, subcategoreyScroll;
    public void SetCategoryUI()
    {
        SetElement(ObjectsManager.instance.categroyDataRoot, categoryBar, categoryPrefab);
    }
    public void SetSubCategoryUI()
    {
        SetElement(ObjectsManager.instance.subCategoryRoot, subcategoreyScroll, subcategoryPrefab);
    }
    public void SetClotheSubcateUI()
    {
        Debug.Log("UI Set is"+ ObjectsManager.instance.clothesDataRoot.data.clothes.Count);
        SetElement(ObjectsManager.instance.clothesDataRoot, highlightScroll, clothePrefab);
    }
    public void SetElement(SubCategoryData.Root subCategoryRoot, ScrollRect scrollRect, SubcategoryComponent component)
    {
        foreach (var item in subcateButtons) { Destroy(item.gameObject); }
        subcateButtons = new List<SubcategoryComponent>();
        for (int j = 0; j < subCategoryRoot.data.subCategories.Count; j++)
        {
            print("nameof(subCategoryRoot)");
            var obj = Instantiate(component);
            obj.transform.parent = scrollRect.content;
            obj.transform.localScale = Vector3.one;
            obj._name.text = subCategoryRoot.data.subCategories[j].name;
            obj.id = subCategoryRoot.data.subCategories[j].id;
            obj.image = null;
            subcateButtons.Add(obj);
            if(j==0)
            {
                obj.gameObject.GetComponent<SubcategoryComponent>().SetColor();
                print("update color");
            }
        }
    }
    public List<CategoryComponent> cateButtons = new List<CategoryComponent>();
    public List<ClotheComponent> clothButtons = new List<ClotheComponent>();
    public List<SubcategoryComponent> subcateButtons = new List<SubcategoryComponent>();
    public void SetElement(CategoryData.Root categoryRoot, Transform parent, CategoryComponent component)
    {
        foreach (var item in cateButtons) { Destroy(item.gameObject); }
        cateButtons = new List<CategoryComponent>();
        for (int j = 0; j < categoryRoot.data.categories.Count; j++)
        {
            print("nameof(subCategoryRoot)");
            var obj = Instantiate(component, parent, true);
            //obj.transform.parent = parent;
            obj.transform.localScale = Vector3.one;
            obj._name.text = categoryRoot.data.categories[j].name;
            obj.id = categoryRoot.data.categories[j].id;
            cateButtons.Add(obj);
        }
    }
    public void SetElement(ClothesData.Root clotheDataRoot, ScrollRect scrollRect, ClotheComponent component)
    {
        foreach (var item in clothButtons) { Destroy(item.gameObject); }
        clothButtons = new List<ClotheComponent>();
        for (int j = 0; j < clotheDataRoot.data.clothes.Count; j++)
        {
            var obj = Instantiate(component);
            obj.transform.parent = scrollRect.content;
            obj.transform.localScale = Vector3.one;
            obj.clothe = clotheDataRoot.data.clothes[j];
            obj._name.text = clotheDataRoot.data.clothes[j].title;
            obj.disTxt.text = clotheDataRoot.data.clothes[j].description;
            obj.orignalPrice.text = clotheDataRoot.data.clothes[j].price;
            obj.price.text = "$" + DiscountResult(clotheDataRoot.data.clothes[j].price, clotheDataRoot.data.clothes[j].discountInPercentage).ToString("00");
            obj.discount.text = clotheDataRoot.data.clothes[j].discountInPercentage.ToString();
            clothButtons.Add(obj);
        }
    }
    public int DiscountResult(string orignalPrice, int discount)
    {
        float Price = (float)Convert.ToDouble(orignalPrice);
        var discounted_price = Price - (Price * discount / 100);
        return (int)discounted_price;
    }
    //////////// cart element set///////////
    public CartObjectComponent cartPrefab;
    public ScrollRect cartScroll;
    public GameObject emptycardtxt;
    public void SetCartsUI(bool OnAddCart)
    {
        for (int i = 0; i < cartScroll.content.childCount; i++)
        {
            Destroy(cartScroll.content.GetChild(i).gameObject);
        }
        total = 0;
        var cartData = ObjectsManager.instance.userDataRoot.data.user.savedCart;
        if(cartData.Count==0)
        {
            emptycardtxt.SetActive(true);
        }
        else
        {
            emptycardtxt.SetActive(false);
        }
        itemTxt.text = "Items (" + cartData.Count + ")";
        for (int i = 0; i < cartData.Count; i++)
        {

            print("set cart number " + i + 1);
            var cartobj = Instantiate(cartPrefab, cartScroll.content);
            cartobj.id = cartData[i].sizeId;
            cartobj._name.text = cartData[i].ClotheSize.clothe.title;
           
            cartobj.size.text = GetSizeOfCloth(cartData[i].ClotheSize.sizeId);
            cartobj.price.text = "$" + (int)DiscountResult(cartData[i].ClotheSize.clothe.price, cartData[i].ClotheSize.clothe.discountInPercentage);
            
            //To improve later
            UpdatePrice(i);
        }
        void UpdatePrice(int i)
        {
            total += (int)DiscountResult(cartData[i].ClotheSize.clothe.price, cartData[i].ClotheSize.clothe.discountInPercentage);
        }
            totalCartPriceTxt.text = "$" + total;
            itemPriceTxt.text = "$" + total;
    }

    public PlacedCartObjectComponent placedCartPrefab;
    public ScrollRect placedCartScroll;
    public GameObject placedEmptycardtxt;
    public void SetPlacedCartsUI(bool OnAddCart)
    {
        itemTxt.text = "Items (" + ObjectsManager.instance.userDataRoot.data.user.savedCart.Count + ")"; 
        Debug.Log("Placed Cart Successfully New");
        for (int i = 0; i < placedCartScroll.content.childCount; i++)
        {
            Destroy(placedCartScroll.content.GetChild(i).gameObject);
        }
        total = 0;
        var placedcOrders = ObjectsManager.instance.allOderData.data.orders;
        if (placedcOrders.Count == 0)
        {
            emptycardtxt.SetActive(true);
        }
        else
        {
            emptycardtxt.SetActive(false);
        }
        itemTxt.text = "Items (" + placedcOrders.Count + ")";
        for (int i = 0; i < placedcOrders.Count; i++)
        {
            for (int y = 0; y < placedcOrders[i].orderDetails.Count; y++)
            {
                print("set cart number " + i + 1);
                var cartobj = Instantiate(placedCartPrefab, placedCartScroll.content);
                cartobj.id = placedcOrders[i].id;
                cartobj._name.text = placedcOrders[i].orderDetails[y].clotheSize.clotheDetails.title;
                cartobj.size.text = /*placedcOrders[i].orderDetails[y].sizeId + "";*/GetSizeOfCloth(placedcOrders[i].orderDetails[y].clotheSize.sizeId);
               // cartobj.size.text = placedcartData[i].clotheSize.sizeId;
                cartobj.price.text = "$" + placedcOrders[i].orderDetails[y].price;
                cartobj.status.text = "Placed";
            }



            //To improve later
            // UpdatePrice(i);
        }
        /*        void UpdatePrice(int i)
                {
                    total += (int)DiscountResult(cartData[i].ClotheSize.clothe.price, cartData[i].ClotheSize.clothe.discountInPercentage);
                }
                totalCartPriceTxt.text = "$" + total;
                itemPriceTxt.text = "$" + total;*/
        SetCartsUI(true);
    }


    public string GetSizeOfCloth(int id)
    {
    
        switch (id)
        {
            case 1: return "XS";           
            case 2: return "S";
            case 3: return "M";
            case 4: return "L";
            case 5: return "XL";
            default: return "M";

        } 

    }

}