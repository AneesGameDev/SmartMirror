using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GPS : MonoBehaviour
{
    public static GPS Instance { set; get; }
    public float Latitude;
    public float Longitude;

    // Start is called before the first frame update
    void Start()
    {
        if(Instance == null)
        {
            Instance = this;

        }
        DontDestroyOnLoad(gameObject);
        StartCoroutine(StartLocationservice());
    }

    private IEnumerator StartLocationservice()
    {
        if(!Input.location.isEnabledByUser)
        {
            Debug.Log("User Has not enabled Gps");
            yield break;
        }
        else
        {
            Debug.Log("User Has enabled Gps");
        }
        Input.location.Start();
        int maxWait = 20;
        while (Input.location.status == LocationServiceStatus.Initializing && maxWait > 0)
        {
            yield return new WaitForSeconds(1);
            maxWait--;
        }
        if(maxWait <= 0)
        {
            Debug.Log("Time Out");
            yield break;
        }
        if(Input.location.status == LocationServiceStatus.Failed)
        {
            Debug.Log("Unable to determin device location");
            yield break;
        }

        Latitude = Input.location.lastData.latitude;
        Longitude = Input.location.lastData.longitude;

        Debug.Log("Latitude ======="+ Latitude);
        Debug.Log("Longitude ======="+ Longitude);


        yield break;
    }
}
