using System.Collections;

using UnityEngine;

using UnityEngine.Networking;
using System;


public class CityGPS : MonoBehaviour 
{

    public string countryname;
    public string cityname;
    public string regionname;
    public float latitudenumber;
    public float longitudenumber;
    public string timezonetime;
    public static CityGPS instence;
   
    // Start is called before the first frame update
    private void Awake()
    {
        if(instence == null)
        {
            instence = this;
        }
    }
    void Start()
    {
        //IpApiData IPData = new IpApiData();
        //countryname = IPData.country_name;
        //cityname = IPData.city;
        //regionname = IPData.region;
        //latitudenumber = IPData.latitude;
        //longitudenumber = IPData.longitude;
        //timezonetime = IPData.timezone;
       // StartCoroutine(SetCountry());

    }

    public void showData()
    {
        StartCoroutine(SetCountry());
    }
   
    public static IEnumerator SetCountry()
    {
        string ip = new System.Net.WebClient().DownloadString("https://api.ipify.org"); 
        string uri = $"https://ipapi.co/{ip}/json/";
        using (UnityWebRequest webRequest = UnityWebRequest.Get(uri))
        {
           // Debug.Log("uri is here"+ uri);
            yield return webRequest.SendWebRequest();

            string[] pages = uri.Split('/');
            int page = pages.Length - 1;

            IpApiData ipApiData = IpApiData.CreateFromJSON(webRequest.downloadHandler.text);

            Debug.Log("this is country name " + ipApiData.country_name);
            Debug.Log("this is city " + ipApiData.city);
            WidgetsManager.instance.CityText.text = ipApiData.city;
            Debug.Log("this is region " + ipApiData.region);
            Debug.Log("this is latitude " + ipApiData.latitude);
            Debug.Log("this is longitude " + ipApiData.longitude);
            Debug.Log("this is timezone " + ipApiData.timezone);
            RealWorldWeather.instance.latitude = ipApiData.latitude;
            RealWorldWeather.instance.longitude = ipApiData.longitude;
            RealWorldWeather.instance.useLatLng = true;
            RealWorldWeather.instance.GetRealWeather();


        }
    }

  

}
[Serializable]
public class IpApiData
{

    public string country_name;
    public string city;
    public string region;
    public float latitude;
    public float longitude;
    public string timezone;

    public static IpApiData CreateFromJSON(string jsonString)
    {
        return JsonUtility.FromJson<IpApiData>(jsonString);
    }


}
