﻿using System;
using System.Collections;
//using Newtonsoft.Json.Linq;
using UnityEngine;
using UnityEngine.Networking;
using System.Collections.Generic;

public class RealWorldWeather : MonoBehaviour {

	public static RealWorldWeather instance;

	public Root rootWeather;


    private void Start()
    {
        if (instance == null)
        {
			instance = this;
        }
		CityGPS.instence.showData();
	}
    /*
		In order to use this API, you need to register on the website.

		Source: https://openweathermap.org

		Request by city: api.openweathermap.org/data/2.5/weather?q={city id}&appid={your api key}
		Request by lat-long: api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={your api key}

		Api response docs: https://openweathermap.org/current
	*/

    public string apiKey = "feddbb498dfc5cb0de20c9704ff5d7b8";

	public string city;
	public bool useLatLng = false;
	public float latitude;
	public float longitude;
    public CityGPS cityGPS;



    public void GetRealWeather () 
	
	{
		
		
		
		string uri = "api.openweathermap.org/data/2.5/weather?";
		if (useLatLng) {
			uri += "lat=" + latitude + "&lon=" + longitude + "&appid=" + apiKey;
		} 
		else {
			uri += "q=" + city + "&appid=" + apiKey;
		}
		//if(useLatLng)
  //      {
		//	uri += "q=" + city + "&appid=" + apiKey;
		//}
		StartCoroutine (GetWeatherCoroutine (uri));
		
	}

	IEnumerator GetWeatherCoroutine (string uri) {
		using (UnityWebRequest webRequest = UnityWebRequest.Get (uri)) {
			yield return webRequest.SendWebRequest ();
			//if (webRequest.isNetworkError)
			if (webRequest.result == UnityWebRequest.Result.ConnectionError || webRequest.result == UnityWebRequest.Result.ProtocolError)
			{
				Debug.Log ("Web request error: " + webRequest.error);
			} else {
				ParseJson (webRequest.downloadHandler.text);
				Debug.Log(webRequest.downloadHandler.text);
			}
		}
	}

	public void ParseJson (string json) {
		//WeatherStatus weather = new WeatherStatus ();
		rootWeather = JsonUtility.FromJson<Root>(json);

		WidgetsManager.instance.SunnyText.text = rootWeather.weather[0].main;
		WidgetsManager.instance.TemperatureText.text = ""+Mathf.Round((float)rootWeather.main.temp - 273f)+ "°";
		WidgetsManager.instance.HLText.text = "H:"+ Mathf.Round((float)rootWeather.main.temp_max - 273f)+ "°"+" "+"L:"+ Mathf.Round((float)rootWeather.main.temp_min - 273f) + "°";

		/*		try {
					//dynamic obj = JObject.Parse (json);

					//Debug.Log("Location  " + );
					weather.weatherId = obj.weather[0].id;
					weather.main = obj.weather[0].main;
					weather.description = obj.weather[0].description;
					weather.temperature = obj.main.temp;
					weather.pressure = obj.main.pressure;
					weather.windSpeed = obj.wind.speed;
				} catch (Exception e) {
					Debug.Log (e.StackTrace);
				}*/

		/*	Debug.Log("weatherId  " +weather.weatherId);
			//Debug.Log("desc    " +weather.description);
			Debug.Log("Main   " +weather.main);
			//Debug.Log("temperature   " +weather.temperature);
			Debug.Log("pressure   " + weather.pressure +"mb");
			Debug.Log ("Temp in °C: " + weather.Celsius ());
			Debug.Log ("Temp in °F: " + weather.Fahrenheit());
	*/
		//CityGPS.IpApiData.






		// return weather;
	}




	[Serializable]
	public class Clouds
	{
		public int all ;
	}
	[Serializable]
	public class Coord
	{
		public double lon ;
		public double lat ;
	}
	[Serializable]
	public class Main
	{
		public double temp ;
		public double feels_like ;
		public double temp_min ;
		public double temp_max ;
		public int pressure ;
		public int humidity ;
	}
	[Serializable]
	public class Root
	{
		public Coord coord ;
		public List<Weather> weather ;
		public string @base ;
		public Main main ;
		public int visibility ;
		public Wind wind ;
		public Clouds clouds ;
		public int dt ;
		public Sys sys ;
		public int timezone ;
		public int id ;
		public string name ;
		public int cod ;
	}
	[Serializable]
	public class Sys
	{
		public int type ;
		public int id ;
		public string country ;
		public int sunrise ;
		public int sunset ;
	}
	[Serializable]
	public class Weather
	{
		public int id ;
		public string main ;
		public string description ;
		public string icon ;
	}
	[Serializable]
	public class Wind
	{
		public double speed ;
		public int deg ;
	}




}