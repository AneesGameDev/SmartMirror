using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ArduinoBluetoothAPI;
public class BluetoothConnection : MonoBehaviour
{
    private void Start()
    {
       // BluetoothHelper.BLE=false;
       BluetoothHelper.GetInstance().Connect();
       BluetoothHelper.GetInstance().getDeviceAddress();
    }
}
