using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class CategoryData
{
    // [Serializable]
    // public class Category
    // {
    //     public int id;
    //     public string name;
    //     public DateTime createdAt;
    //     public DateTime updatedAt;
    // }
    // [Serializable]
    // public class Root
    // {
    //     public string status;
    //     public List<Category> categories;
    // }
    //////new
[Serializable]
    public class Category
    {
        public int id;
        public string name;
        public DateTime createdAt;
        public DateTime updatedAt;
    }
[Serializable]

    public class Data
    {
        public List<Category> categories;
    }
[Serializable]
    public class Root
    {
        public string status;
        public bool error;
        public Data data;
    }
}
