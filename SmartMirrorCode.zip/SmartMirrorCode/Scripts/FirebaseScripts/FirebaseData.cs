/*using System;
using System.Collections;
using System.Collections.Generic;
//using UnityEditor.VersionControl;
using UnityEngine;
using Firebase;
using Firebase.RemoteConfig;
using System.Threading.Tasks;
using Firebase.Extensions;
using UnityEngine.Networking;
using Firebase.Storage;
using UnityEngine.UI;

public class FirebaseData : MonoBehaviour
{

    public RawImage rawImage;
    FirebaseStorage storage;
    StorageReference storageReference;

    IEnumerator LoadImage(string MediaUrl)
    {
        UnityWebRequest request = UnityWebRequestTexture.GetTexture(MediaUrl); //Create a request
        yield return request.SendWebRequest(); //Wait for the request to complete
        if (request.isNetworkError || request.isHttpError)
        {
            Debug.Log(request.error);
        }
        else
        {
            rawImage.texture = ((DownloadHandlerTexture)request.downloadHandler).texture;
            // setting the loaded image to our object
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        rawImage = gameObject.GetComponent<RawImage>();
        //  StartCoroutine(LoadImage("https://firebasestorage.googleapis.com/v0/b/mirrortracking.appspot.com/o/VikingsLogo.jpg?alt=media&token=8ff3f81e-38d8-47f4-899b-ffd80dbe8c4b"));
        //Easy hardcoded solution But bad approach

        //initialize storage reference
        storage = FirebaseStorage.DefaultInstance;
        storageReference = storage.GetReferenceFromUrl("gs://sm-app-366617.appspot.com/");

        //get reference of image
        StorageReference image = storageReference.Child("VikingsLogo.jpg");

        //Get the download link of file
        image.GetDownloadUrlAsync().ContinueWithOnMainThread(task =>
        {
            if (!task.IsFaulted && !task.IsCanceled)
            {
                StartCoroutine(LoadImage(Convert.ToString(task.Result))); //Fetch file from the link
             }
            else
            {
                Debug.Log(task.Exception);
            }
        });
    }



}

*/