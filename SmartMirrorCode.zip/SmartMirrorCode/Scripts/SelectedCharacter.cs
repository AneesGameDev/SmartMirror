using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UMA;
using UMA.CharacterSystem;
using UnityEngine.UI;

public class SelectedCharacter : MonoBehaviour
{

    private int _characterSelection;
    [SerializeField]
    private GameObject  CustomizeCharacter , UMAprefab;
    [SerializeField]
    private CustomizeController _customizeContorller;
    
    //public DynamicCharacterAvatar _dynamicCharactermaleAvatar;
    private SaveCustomizeData saveData;
    //public GameObject MaleButton, FemalButton;
    private float startingPosition;
    private bool CanRotate , AreaClick;
    private float rotatespeed ;
    public Button _3DButton;
    //public Button AreaOfMovementCharacterBTN;
    private float _screenBottomLimit , _screenUpperLimit , _screenSmallPart;
    private GameObject move3DCharacter;
    public static bool FirstTime = true;

    // public RectTransform rect;
    //  private GameObject UIManagerObj;
    //  private CustomizeController _cutomizeController;

    private void Awake()
    {
        saveData = FindObjectOfType<SaveCustomizeData>();
    }
    

    // Start is called before the first frame update
    void Start()
    {
        _screenSmallPart = Screen.height / 12;
        _screenBottomLimit = Screen.height / 2 + _screenSmallPart;
        _screenUpperLimit = Screen.height - _screenSmallPart; 
        CanRotate = false;
        rotatespeed = 300f;
        if (_customizeContorller == null)
        {
            _customizeContorller = FindObjectOfType<CustomizeController>();
        }
        

        //if (MaleButton && FemalButton != null) MaleButton.SetActive(true); FemalButton.SetActive(true);

        //_cutomizeController = UIManagerObj.GetComponent<CustomizeController>();
        //UMA.UMADNA
        _3DButton.gameObject.GetComponent<Image>().color = Color.white;
        _3DButton.onClick.AddListener(()=>ButtonClick3Dview());
        //AreaOfMovementCharacterBTN.onClick.AddListener(() => DragClickCharacter());
        //AreaOfMovementCharacterBTN. AddListener(() => DragClickCharacter());
       //ShowSelectedCharacter();

    }

    // Update is called once per frame
    void Update()
    {


        if (Input.touchCount > 0 && CanRotate )
        {
           


            Debug.Log("Touch Count is Working");
            Touch touch = Input.GetTouch(0);
            
            switch (touch.phase)
            {
                case TouchPhase.Began:
                    startingPosition = touch.position.x;
                    break;
                case TouchPhase.Moved:
                   if(touch.position.y> _screenBottomLimit && touch.position.y < _screenUpperLimit) { 
                    if (startingPosition > touch.position.x)
                    {
                            move3DCharacter.transform.Rotate(Vector3.up, rotatespeed * Time.deltaTime);
                    }
                    else if (startingPosition < touch.position.x)
                    {
                            move3DCharacter.transform.Rotate(Vector3.up, -rotatespeed * Time.deltaTime);
                    }
                    }
                    break;
                case TouchPhase.Ended:
                    Debug.Log("Touch Phase Ended.");
                    break;
                case TouchPhase.Stationary:
                    startingPosition = touch.position.x;
                    break;
           
        }
        }
    }


    public void SelectionCharacterButton(int param)
    {
        if (UMAprefab != null) UMAprefab.SetActive(false);
        _characterSelection = param;
       
    }
   
    
    public void ShowSelectedCharacter()
    {
       StartCoroutine(ShowSelectedCharacterEnumerator());
        //if (UMAprefab != null) UMAprefab.SetActive(false);

        /*            if(_characterSelection == 0)
                    {
                        MaleButton.SetActive(true);
                        FemalButton.SetActive(false);
                        saveData.dataObj.male = true;
                        CustomizeCharacter.SetActive(true);
                        _femalCharacter.SetActive(false);
                        _dynamicCharactermaleAvatar = CustomizeCharacter.GetComponent<DynamicCharacterAvatar>();
                         move3DCharacter = CustomizeCharacter;

                    }
                    else if(_characterSelection==1)
                    {
                        MaleButton.SetActive(false);
                        FemalButton.SetActive(true);
                        saveData.dataObj.male = false;
                        _femalCharacter.SetActive(true);
                        CustomizeCharacter.SetActive(false);
                        _dynamicCharacterfemaleAvatar = _femalCharacter.GetComponent<DynamicCharacterAvatar>();
                        move3DCharacter = _femalCharacter; 

                    }*/
        //_cutomizeController._avatar = _dynamicCharacterAvatar;


    }

    public IEnumerator ShowSelectedCharacterEnumerator()
    {
        if (UMAprefab != null && !UMAprefab.activeSelf) UMAprefab.SetActive(true);

        while (!UMAprefab.activeSelf)
        {
            yield return null;
        }

        if (UMAprefab.activeSelf)
        {

            CustomizeCharacter.SetActive(true);
            //_femalCharacter.SetActive(false);
            //_dynamicCharactermaleAvatar = CustomizeCharacter.GetComponent<DynamicCharacterAvatar>();
            
            move3DCharacter = CustomizeCharacter;
            if (FirstTime)
            {
                Debug.Log("First Time is Called");
                new WaitForSeconds(1f);
                SelectAvatarRace();
                
                
            }

            Debug.Log("Show Selceted Character Enumerator");
        }
    }

    public void DisableActivatedCharacter()
    {
        CustomizeCharacter.SetActive(false);
        
        UMAprefab.SetActive(false);
    }

    public void SelectAvatarRace()
    {
        if (_customizeContorller._avatar != null) {
/*            PlayerPrefs.SetString("Email", LogText.Email);
            PlayerPrefs.SetString("Password", LogText.Password);
            PlayerPrefs.SetString("Age", ObjectsManager.instance.userDataRoot.data.user.dob);
            PlayerPrefs.SetString("Gender", ObjectsManager.instance.userDataRoot.data.user.gender);*/
            if(PlayerPrefs.HasKey("Age") && PlayerPrefs.HasKey("Gender"))
            {


            if (PlayerPrefs.GetString("Gender") == "Male")
            {
                saveData.dataObj.male = true;
                int.TryParse(PlayerPrefs.GetString("Age"), out int AgeInInteger);
                //GetAvatarRaceByAge(AgeInInteger, true);
                Debug.Log("Age Of USer Male is" + AgeInInteger);
                _customizeContorller._avatar.ChangeRace(GetAvatarRaceByAge(AgeInInteger, true));
                //_customizeContorller.GetAvatarButton();
              //  _customizeContorller._avatar.ChangeRace("HumanMaleDCS");

            }else
        if (PlayerPrefs.GetString("Gender") == "Female")
        {
            saveData.dataObj.male = false;
                int.TryParse(PlayerPrefs.GetString("Age"), out int AgeInInteger);
                // GetAvatarRaceByAge(AgeInInteger, false);
                Debug.Log("Age Of USer Female is" + AgeInInteger);
                _customizeContorller._avatar.ChangeRace(GetAvatarRaceByAge(AgeInInteger, false)) ;
               // _customizeContorller._avatar.ChangeRace("HumanMaleDCS");
            }

        }
        else
        {
                Debug.Log("Age and Gender is not available");
            Debug.LogError("Dynamic Avatar is null in SelectedAvatraRace()");
           // _customizeContorller._avatar = CustomizeCharacter.GetComponent<DynamicCharacterAvatar>();
            //SelectAvatarRace();
        }
        }
        if (FirstTime)
        {
            Invoke(nameof(DisableActivatedCharacter), 2f);
            Debug.Log("Invoke of DIsable is called");
        }

 /*       DisableActivatedCharacter();
        Invoke(nameof(DisableActivatedCharacter), 2f);
      */
        //_customizeContorller.GetAvatarButton();
    }


    private string GetAvatarRaceByAge(int Age , bool Male)
    {
       int CurrentYear =System.DateTime.Now.Year;
        int AgeOfUser = CurrentYear - Age;
        Debug.Log("Age is... " + AgeOfUser);
        if (Male)
        {
            if (AgeOfUser <= 16)
            {
                Debug.Log("Male Chiled IS Called For Character Selection");
                return "MaleChidd";// MaleChilds
            }
            if (AgeOfUser >= 16 && AgeOfUser <= 30)
            {
                Debug.Log("Male Teen is Called For Character Selection");
                return "MaleTeenChild";
            }
            if (AgeOfUser >= 31)
            {
                Debug.Log("Male Grownup is Called For Character Selection");
                return "MaleGrownup";
            }
        }else
        {
            if (AgeOfUser <= 16)
            {
                Debug.Log("Female Chiled IS Called For Character Selection");
                return "femalechildd";
            }
            if (AgeOfUser >= 16 && AgeOfUser <= 30)
            {
                Debug.Log("Female Teen is Called For Character Selection");
                return "FemaleGrownupp";
            }
            if (AgeOfUser >= 31)
            {
                Debug.Log("Female Grownup is Called For Character Selection");
                return "FemaleTeenn";
            }
            //Debug.Log("Female is Called");
        }
        return "";

    }


    public void ButtonClick3Dview()
    {
        if (!CanRotate)
        {
            CanRotate = true;
            _3DButton.gameObject.GetComponent<Image>().color = Color.black;
        }
        else if(CanRotate)
        {
            Reset3DViewObject();
        }
    }

    public void Reset3DViewObject()
    {
        CanRotate = false;
        move3DCharacter.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
        _3DButton.gameObject.GetComponent<Image>().color = Color.white;
    }

}
