using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.IO;


public class ShopManager : MonoBehaviour
{
    public static ShopManager instance;
    public GameObject HistoryPanel;
    public static int MainCategorie = 1;
    public static int SubCategorie = 1;
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
    }
    private void Start()
    {
        OnGetSubcategory.AddListener(() => GetClotheSubcategory(ObjectsManager.instance.subCategoryRoot.data.subCategories[0].id));
        /* OnOrderPlaced.AddListener(() =>
         {
             GetPlacedOrders();
         });*/
        OnOrderPlacedSuccessfully.AddListener(() => {
            ShopUI.instance.SetPlacedCartsUI(true);
             HistoryPanel.gameObject.SetActive(true);
           
            });
    }
    public CartDataLocal.Root cartdata = new CartDataLocal.Root();
    public UnityEvent OnGetCategory, OnGetSubcategory, OnGetClotheOfSubcate, OnAddCartSuccess, OnOrderPlacedSuccessfully;
    [HideInInspector]
    public UnityEvent OnOrderPlaced;
    public void ScanClick()
    {
        SceneManager.LoadScene("scan", LoadSceneMode.Additive);
    }

    public void ShopClick()
    {
        StartCoroutine(APIHelper.GetData(APIHelper.categorieAdd, null));
    }
    public void GetCategory()
    {
        StartCoroutine(APIHelper.GetData(APIHelper.categorieAdd, OnGetCategory));
    }
    public void GetClotheSubcategory(int endPoint)
    {
        SubCategorie = endPoint;

        StartCoroutine(APIHelper.GetData(APIHelper.subCategorieClothesAdd + endPoint, OnGetClotheOfSubcate));
    }
    public void GetClotheSearch(Text Keyword)
    {
        
        if (Keyword.text == ""|| Keyword.text ==" ")
        {
            GetClotheSubcategory(SubCategorie);
        }
        else { 
        string keywordSearch = "" + MainCategorie + "?searchKeyword=" + Keyword.text;
        Debug.Log("Keyword of Search is" + Keyword.text);
        StartCoroutine(APIHelper.GetData(APIHelper.AllCategoryCloth + keywordSearch, OnGetClotheOfSubcate));
        }
    }
    public void SearchReback()
    {
        GetClotheSubcategory(SubCategorie);
    }
    public void GetSubCategory(int endPoint)
    {
        MainCategorie = endPoint;
        StartCoroutine(APIHelper.GetData(APIHelper.subCategorieAdd + endPoint, OnGetSubcategory));
    }
    public void NewOrderPost()
    {
        Debug.Log("Cart List Items Count" + JsonUtility.ToJson(newOderFormObj));
        StartCoroutine(APIHelper.PostRaw(JsonUtility.ToJson(newOderFormObj), APIHelper.newOrderAdd, OnAddCartSuccess));
    }
    public void GetPlacedOrders()
    {
        Debug.Log("Placed Orders Data Getting");
        StartCoroutine(APIHelper.GetData(APIHelper.orderList, OnOrderPlacedSuccessfully));
    }
    public void ConfirmOrderPost()
    {
        OnOrderPlaced.AddListener(() => {
            GetPlacedOrders();
            ClotheFullViewComponent.instance.DeleteAllSavedCart();

        });
        Debug.Log("ConfirmOrderPost" + JsonUtility.ToJson(newOderFormObj));
        newOderFormObj.status = "placed";
        StartCoroutine(APIHelper.PostRaw(JsonUtility.ToJson(newOderFormObj), APIHelper.newOrderAdd, OnOrderPlaced));
        //GetPlacedOrders();
    }
    /*     public void DeleteSavedCart()
        {
            newOderFormObj
        }
    */
    public void AddCartDataOfLogin()
    {
        for (int i = 0; i < ObjectsManager.instance.userDataRoot.data.user.savedCart.Count; i++)
        {
            NewOderForm.Cart cart = new NewOderForm.Cart();
            // if(ObjectsManager.instance.userDataRoot.data.user.savedCart[i].price=="")
            // {
            //     return;
            // }
            cart.price = int.Parse(ObjectsManager.instance.userDataRoot.data.user.savedCart[i].price);
            cart.sizeId = ObjectsManager.instance.userDataRoot.data.user.savedCart[i].ClotheSize.sizeId;
            cart.quantity = int.Parse(ObjectsManager.instance.userDataRoot.data.user.savedCart[i].quantity);
            newOderFormObj.cart.Add(cart);
        }
    }
    public NewOderForm.Root newOderFormObj;
}
[System.Serializable]
public class NewOderForm
{
    public Root root;
    [System.Serializable]
    public class Cart
    {
        public int sizeId;
        public int quantity;
        public int price;
    }
    [System.Serializable]
    public class Root
    {
        public Root(Cart _cart, string status)
        {
            this.status = status;
            cart.Add(_cart);
        }
        public string status;
        public List<Cart> cart = new List<Cart>();
    }
    // string GetClotheNameById(int id)
    // {
    //     for (int i = 0; i < ; i++)
    //     {
    //        var v= ObjectsManager.instance.clothesDataRoot.data.clothes[i].clotheSizes.Find(r => r.id == id);
    //        return v.cl;
    //     }
    // }
}
