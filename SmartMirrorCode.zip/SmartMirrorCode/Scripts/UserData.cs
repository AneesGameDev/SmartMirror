using System;
using System.Collections.Generic;
using UnityEngine;

public class UserData
{
    [Serializable]
    public class Data
    {
        public User user;
        public string accessToken;
    }
    [Serializable]
    public class Root
    {
        public string status;
        public bool error;
        public Data data;
    }
    [Serializable]
    public class SavedCart
    {
        public int id;
        public int sizeId;
        public string quantity;
        public string price="0";
        public int userId;
        public DateTime createdAt;
        public DateTime updatedAt;
        public ClotheSize ClotheSize=new ClotheSize();
    }
    [Serializable]
    public class ClotheSize
    {
        public int id;
        public int clotheId;
        public int sizeId;
        public int quantity;
        public DateTime createdAt;
        public DateTime updatedAt;
        public Clothe clothe=new Clothe();
    }
    [Serializable]
    public class Clothe
    {
        public Clothe()
        {

        }
        public int id;
        public string title;
        public int categoryId;
        public int subCategoryId;
        public string description;
        public string price;
        public object image;
        public int discountInPercentage;
        public DateTime createdAt;
        public DateTime updatedAt;
    }
    [Serializable]
    public class User
    {
        public int id;
        public string firstName;
        public string lastName;
        public string password;
        public string email;
        public string role;
        public string dob;
        public string gender;
        public List<SavedCart> savedCart;
    }
}
