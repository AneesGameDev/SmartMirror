using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AIHelper : MonoBehaviour
{
    private void Start() {
        var v=FindObjectsOfType<InputField>();
        
    }
}
