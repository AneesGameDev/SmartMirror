using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class SignupData
{
    // [Serializable]
    // public class Root
    // {
    //     public string status ;
    //     public string message ;
    //     public User user ;
    // }
    // [Serializable]
    // public class User
    // {
    //     public bool isActive ;
    //     public string role ;
    //     public int id ;
    //     public string firstName ;
    //     public string lastName ;
    //     public string email ;
    //     public string password ;
    //     public DateTime updatedAt ;
    //     public DateTime createdAt ;
    //     public object phone ;
    //}
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    [Serializable]
    public class Data
    {
        public string message;
        public User user;
    }
    [Serializable]
    public class Root
    {
        public string status;
        public bool error;
        public Data data;
    }
    [Serializable]
    public class User
    {
        public bool isActive;
        public string role;
        public int id;
        public string firstName;
        public string lastName;
        public string email;
        public string password;
        public DateTime updatedAt;
        public DateTime createdAt;
        public object phone;
    }
}
