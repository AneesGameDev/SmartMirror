using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class ClotheFullViewComponent : MonoBehaviour
{
    public static ClotheFullViewComponent instance;
    public List<GameObject> x;
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
    }
    public TMP_Text _name;
    public TMP_Text Title;
    public TMP_Text discription;
    public GameObject[] starts;
    public GameObject[] sizes;
    public TMP_Text price;
    public ClothesData.Clothe clothe;
    public int currentSizeId,currentId;
    public void SetUIData()
    {
        Title.text = clothe.subCategory.name;
        _name.text = clothe.title;
        discription.text = clothe.description;
        price.text ="$"+DiscountResult(clothe.price, clothe.discountInPercentage).ToString("00");
        // set sizes ui of clohte---------
        foreach (var item in sizes)
        {
            item.gameObject.SetActive(false);
        }
        for (int i = 0; i < clothe.clotheSizes.Count; i++)
        {
            if (sizes.Length <= i)
                break;
            sizes[i].SetActive(true);
            sizes[i].GetComponent<ClotheSizeObject>().clotheSize.id=clothe.clotheSizes[i].id;
            sizes[i].name = clothe.clotheSizes[i].sizeId.ToString();
           // sizes[i].GetComponent<ClotheSizeObject>().clotheSize.=clothe.clotheSizes[i].sizes.name;
            sizes[i].transform.GetChild(0).GetComponent<Text>().text = clothe.clotheSizes[i].sizes.name;
        }
        if (clothe.clotheSizes.Count > 0)
            currentSizeId = clothe.clotheSizes[0].sizeId;
        //Debug.Log("First Current Id id" + currentSizeId);
        foreach (var item in sizes)
        {
            item.GetComponent<Image>().color = Color.white;
        }
        sizes[0].GetComponent<Image>().color = SelectedColor;
        currentId = clothe.clotheSizes[0].id;
        // set review starts-------------
        foreach (var item in starts)
        {
            item.transform.GetChild(0).gameObject.SetActive(false);
        }
        if (clothe.Reviews.Count > 0)
        {
            SetStarts();
        }
    }
    public int DiscountResult(string orignalPrice, int discount)
    {
        //discounted_price = original_price - (original_price * discount / 100)
        float Price=(float)Convert.ToDouble(orignalPrice);
        var discounted_price = Price-(Price*discount/100);
        return (int)discounted_price;
    }
    public void SetStarts()
    {
        int sumOfReviews = 0;
        for (int i = 0; i < clothe.Reviews.Count; i++)
        {
            sumOfReviews += clothe.Reviews[i].review;
        }
        int avg = sumOfReviews / clothe.Reviews.Count;
        for (int i = 0; i < (int)avg; i++)
        {
            starts[i].transform.GetChild(0).gameObject.SetActive(true);
        }
    }
    public Color SelectedColor;
    public void OnSizeButtonClick(GameObject obj)
    {
        foreach (var item in sizes)
        {
            item.GetComponent<Image>().color=Color.white;
        }
        obj.GetComponent<Image>().color=SelectedColor;
        ClotheSizeObject clotheSizeObj=obj.GetComponent<ClotheSizeObject>();
        currentSizeId = int.Parse(UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject.name);
      //  currentSizeId=clotheSizeObj.clotheSize.sizeId;
        currentId=clotheSizeObj.clotheSize.id;
        Debug.Log("Current ID Is" + currentId + "Sze Id is "+ currentSizeId);
    }
    public NewOderForm.Root oderForm;
    public void OnAddCartButtonClick()
    {

        NewOderForm.Cart cart=new NewOderForm.Cart();
        UserData.SavedCart savedCart=new UserData.SavedCart();
        cart.price=DiscountResult(clothe.price, clothe.discountInPercentage);
        cart.sizeId=currentId;
        cart.quantity=1;
        ShopManager.instance.newOderFormObj.cart.Add(cart);
        savedCart.ClotheSize.clothe.price = clothe.price;
        savedCart.sizeId = cart.sizeId;
        savedCart.ClotheSize.sizeId = currentSizeId;
        savedCart.ClotheSize.clothe.title = clothe.title;
        savedCart.ClotheSize.clothe.discountInPercentage = clothe.discountInPercentage;
        ObjectsManager.instance.userDataRoot.data.user.savedCart.Add(savedCart);
        ShopManager.instance.newOderFormObj.status = "saved";
        ShopManager.instance.NewOrderPost();
        ShopUI.instance.SetCartsUI(true);

    }


    public void DeleteAllSavedCart()
    {
        ShopManager.instance.newOderFormObj.cart.Clear();
        ObjectsManager.instance.userDataRoot.data.user.savedCart.Clear();
        ShopUI.instance.SetCartsUI(true);
    }


}
