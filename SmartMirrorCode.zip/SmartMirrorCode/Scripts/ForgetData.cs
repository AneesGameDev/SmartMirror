using System;
using UnityEngine;

public class ForgetData : MonoBehaviour
{
    // [Serializable]
    // public class Root
    // {
    //     public string status ;
    //     public string reset_token ;
    // }
    [Serializable]
    public class Data
    {
        public string reset_token;
    }

    [Serializable]
    public class Root
    {
        public string status;
        public bool error;
        public Data data;
    }
}
