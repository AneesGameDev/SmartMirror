using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[Serializable]
public class SubCategoryData : MonoBehaviour
{
[Serializable]
    public class Category
    {
        public string name ;
    }
[Serializable]
    public class Data
    {
        public List<SubCategory> subCategories ;
    }
[Serializable]
    public class Root
    {
        public string status ;
        public bool error ;
        public Data data ;
    }
[Serializable]
    public class SubCategory
    {
        public int id ;
        public string name ;
        public int categoryId ;
        public object brandName ;
        public DateTime createdAt ;
        public DateTime updatedAt ;
        public Category category ;
    }


}
