/*using System.Collections;
using System.Collections.Generic;
using UnityEngine.Networking;
using UnityEngine;
using System.Net;
using System.Text;
using System.IO;
public static class APIHelper
{
    public delegate void OnLogin();
    public delegate void OnSignup();
    public delegate void OnForgetPassword();
    public delegate void OnResetPassword();
    //public delegate void OnLogin();
    public static string server = "http://54.234.242.24:8080/api/v1/";
    //local server
    //public static string server = "http://192.168.1.175:8080/api/v1/";
    public static string loginAdd = "auth/login";
    public static string forgetAdd = "auth/forgot-password";
    public static string resetAdd = "auth/reset-password";
    public static string categorieAdd = "category";
    public static string subCategorieAdd = "category/allsubcategory/";
    public static string subCategorieClothesAdd = "clothe/allsubcategoryclothes/";
    public static string postmanToken = "Token";
    public static string newOrderAdd="checkout";
    public static IEnumerator Login(string id, string password)
    {
        WWWForm form = new WWWForm();
        form.AddField("email", id);
        form.AddField("password", password);
        UnityWebRequest request = UnityWebRequest.Post(server + "auth/login", form);
        yield return request.SendWebRequest();
        if (request.result != UnityWebRequest.Result.Success)
        {
            LogText.instance.ShowLog("Login Failed! please try again" + request.error);
            Debug.Log(request.error);
        }
        else
        {
            LogText.instance.ShowLog("Login completed successfully");
            Debug.Log("Form upload complete!");
        }
        // HttpWebResponse response=request.GetResponse();
        // StreamReader reader=new StreamReader(response.GetResponseStream());
        // string json=reader.ReadToEnd();
        // return json;
    }
    public static IEnumerator Signup(string firstName, string lastName, string id, string password, string DOB, string Gender, UnityEngine.Events.UnityEvent successEvent)
    {
        WWWForm form = new WWWForm();
        form.AddField("firstName", firstName);
        form.AddField("lastName", lastName);
        form.AddField("email", id);
        form.AddField("password", password);
        form.AddField("dob", DOB);
        form.AddField("gender", Gender);
        UnityWebRequest request = UnityWebRequest.Post(server + "auth/register", form);
        yield return request.SendWebRequest();
        if (request.result != UnityWebRequest.Result.Success)
        {
            ObjectsManager.instance.logErrorRoot = JsonUtility.FromJson<LogError.Root>(request.downloadHandler.text);
            LogText.instance.ShowLog(ObjectsManager.instance.logErrorRoot.data.message+ "SignUp Failed! please try again");
            Debug.Log(request.error);
            Debug.Log(request.downloadHandler.text);
        }
        else
        {
            successEvent?.Invoke();
            Authentication.instance.signupPanel.SetActive(false);
            Authentication.instance.loginPanel.SetActive(true);
            LogText.instance.ShowLog("Signup Completed successfully");
            Debug.Log("Form upload complete!");
            ObjectsManager.instance.signupDataRoot = JsonUtility.FromJson<SignupData.Root>(request.downloadHandler.text);
            Debug.Log(ObjectsManager.instance.signupDataRoot);
        }
    }
    public static IEnumerator GetData(string address,UnityEngine.Events.UnityEvent successEvent)
    {
        var request = new UnityWebRequest(server + address, "Get");
        request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        var token = PlayerPrefs.GetString("token");
        Debug.Log("category data called");
        if (token != null)
        {
            request.SetRequestHeader("Authorization", "Bearer "+token);
            Debug.Log(token);
        }
        yield return request.SendWebRequest();
        if (request.result != UnityWebRequest.Result.Success)
        {
            ObjectsManager.instance.logErrorRoot = JsonUtility.FromJson<LogError.Root>(request.downloadHandler.text);
            LogText.instance.ShowLog(ObjectsManager.instance.logErrorRoot.data.message + " Error");
            Debug.Log(request.error);
            Debug.Log(request.downloadHandler.text);
        }
        else
        {
            if (address == categorieAdd)
            {
               // LogText.instance.ShowLog("Get category complete");
                Debug.Log("Get category complete");
                ObjectsManager.instance.categroyDataRoot = JsonUtility.FromJson<CategoryData.Root>(request.downloadHandler.text);
                Debug.Log(JsonUtility.FromJson<CategoryData.Root>(request.downloadHandler.text));
            }
            if (address.Contains(subCategorieAdd))
            {
                //LogText.instance.ShowLog("Get subcategroy complete");
                Debug.Log("Get subcategroy complete");
                ObjectsManager.instance.subCategoryRoot = JsonUtility.FromJson<SubCategoryData.Root>(request.downloadHandler.text);
                Debug.Log(JsonUtility.FromJson<SubCategoryData.Root>(request.downloadHandler.text));
            }
            if (address.Contains(subCategorieClothesAdd))
            {
               // LogText.instance.ShowLog("Get clothes complete");
                Debug.Log("Get clothes complete");
                ObjectsManager.instance.clothesDataRoot = JsonUtility.FromJson<ClothesData.Root>(request.downloadHandler.text);
                Debug.Log(JsonUtility.FromJson<SubCategoryData.Root>(request.downloadHandler.text));
            }
            successEvent?.Invoke();
        }
    }
    public static IEnumerator PostRaw(string obj, string address,UnityEngine.Events.UnityEvent successEvent)
    {

        
        var request = new UnityWebRequest(server + address, "POST");
        // add for token
        request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        var token = PlayerPrefs.GetString("token");
        Debug.Log("category data called"+ obj);
        if (token != null)
        {
            request.SetRequestHeader("Authorization", "Bearer "+token);
            Debug.Log(token);
        }
        //
        byte[] bodyRaw = Encoding.UTF8.GetBytes(obj);
        Debug.Log(bodyRaw.ToString());
        request.uploadHandler = (UploadHandler)new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");
        yield return request.SendWebRequest();
        if (request.result != UnityWebRequest.Result.Success)
        {
            ObjectsManager.instance.logErrorRoot = JsonUtility.FromJson<LogError.Root>(request.downloadHandler.text);
            LogText.instance.gameObject.SetActive(true);
            LogText.instance.ShowLog(ObjectsManager.instance.logErrorRoot.data.message+"Failed to Add Cart");
            Debug.Log(request.error);
            Debug.Log(request.downloadHandler.text);
        }
        else
        {
            
            var v = request.downloadHandler.text;
            Debug.Log(v);
            if (address == loginAdd)
            {
                ObjectsManager.instance.userDataRoot = JsonUtility.FromJson<UserData.Root>(request.downloadHandler.text);
                PlayerPrefs.SetString("token", ObjectsManager.instance.userDataRoot.data.accessToken);
                Debug.Log("Token is" + ObjectsManager.instance.userDataRoot.data.accessToken);

                LogText.instance.ShowLog("login complete");
                Debug.Log("login complete");
                if (PlayerPrefs.HasKey("Email") && PlayerPrefs.HasKey("Age"))
                {
                    if (ObjectsManager.instance.userDataRoot.data.user.email == PlayerPrefs.GetString("Email"))
                    {
                        Debug.Log("Email Exist and Do Nothing new");
                    }
                    else if(ObjectsManager.instance.userDataRoot.data.user.email != PlayerPrefs.GetString("Email"))
                    {
                        PlayerPrefs.SetString("Email", LogText.instance.tempMail);
                        Debug.Log("New Email Set"+ LogText.Email);
                        PlayerPrefs.SetString("Password", LogText.instance.tempPassword);
                        PlayerPrefs.SetString("Age", ObjectsManager.instance.userDataRoot.data.user.dob);
                        PlayerPrefs.SetString("Gender", ObjectsManager.instance.userDataRoot.data.user.gender);
                    }
                }

                if (!PlayerPrefs.HasKey("Email") && !PlayerPrefs.HasKey("Age"))
                {
                    PlayerPrefs.SetString("Email", ObjectsManager.instance.userDataRoot.data.user.email);
                    PlayerPrefs.SetString("Password", ObjectsManager.instance.userDataRoot.data.user.password);
                    PlayerPrefs.SetString("Age", ObjectsManager.instance.userDataRoot.data.user.dob);
                    PlayerPrefs.SetString("Gender", ObjectsManager.instance.userDataRoot.data.user.gender);
                }

                //              Authentication.instance.loginPanel.SetActive(false);
                //              Authentication.instance.mainPanel.SetActive(true);

            }
            if (address == forgetAdd)
            {
                LogText.instance.ShowLog("forget complete");
                Debug.Log("forget complete");
                Authentication.instance.forgetPanel.SetActive(false);
                Authentication.instance.resetPanel.SetActive(true);
                ObjectsManager.instance.forgetDataRoot = JsonUtility.FromJson<ForgetData.Root>(request.downloadHandler.text);
            }
            if (address == resetAdd)
            {
                LogText.instance.ShowLog("reset complete");
                Authentication.instance.loginPanel.SetActive(true);
                Authentication.instance.resetPanel.SetActive(false);
                Debug.Log("reset complete");
                // ObjectsManager.instance.userDataRoot = JsonUtility.FromJson<UserData.Root>(request.downloadHandler.text);
            }

            successEvent?.Invoke();
            //PlayerPrefs.SetString("AccessToken");
        }
    }



}

*/
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Networking;
using UnityEngine;
using System.Net;
using System.Text;
using System.IO;
public static class APIHelper
{
    public delegate void OnLogin();
    public delegate void OnSignup();
    public delegate void OnForgetPassword();
    public delegate void OnResetPassword();
    //public delegate void OnLogin();
    public static string server = "http://54.234.242.24:8080/api/v1/";
    //local server
    //public static string server = "http://192.168.1.175:8080/api/v1/";
    public static string loginAdd = "auth/login";
    public static string forgetAdd = "auth/forgot-password";
    public static string resetAdd = "auth/reset-password";
    public static string verifyForgotPassword = "auth/verifyforgotpassword";
    public static string categorieAdd = "category";
    public static string subCategorieAdd = "category/allsubcategory/";
    public static string subCategorieClothesAdd = "clothe/allsubcategoryclothes/";
    public static string postmanToken = "Token";
    public static string newOrderAdd = "checkout";
    public static string orderList = "checkout/orderlist";
    public static string AllCategoryCloth = "clothe/allcategoryclothes/";
    public static IEnumerator Login(string id, string password)
    {
        WWWForm form = new WWWForm();
        form.AddField("email", id);
        form.AddField("password", password);
        UnityWebRequest request = UnityWebRequest.Post(server + "auth/login", form);
        yield return request.SendWebRequest();
        if (request.result != UnityWebRequest.Result.Success)
        {
            LogText.instance.ShowLog("Login Failed! please try again" + request.error);
            Debug.Log(request.error);
        }
        else
        {
            LogText.instance.ShowLog("Login completed successfully");
            Debug.Log("Form upload complete!");
        }
        // HttpWebResponse response=request.GetResponse();
        // StreamReader reader=new StreamReader(response.GetResponseStream());
        // string json=reader.ReadToEnd();
        // return json;
    }
    public static IEnumerator Signup(string firstName, string lastName, string id, string password, string DOB, string Gender, UnityEngine.Events.UnityEvent successEvent)
    {
        WWWForm form = new WWWForm();
        form.AddField("firstName", firstName);
        form.AddField("lastName", lastName);
        form.AddField("email", id);
        form.AddField("password", password);
        form.AddField("dob", DOB);
        form.AddField("gender", Gender);
        UnityWebRequest request = UnityWebRequest.Post(server + "auth/register", form);
        yield return request.SendWebRequest();
        if (request.result != UnityWebRequest.Result.Success)
        {
            ObjectsManager.instance.logErrorRoot = JsonUtility.FromJson<LogError.Root>(request.downloadHandler.text);
            LogText.instance.ShowLog(ObjectsManager.instance.logErrorRoot.data.message);
            Debug.Log(request.error);
            Debug.Log(request.downloadHandler.text);
        }
        else
        {
            successEvent?.Invoke();
            Authentication.instance.signupPanel.SetActive(false);
            Authentication.instance.loginPanel.SetActive(true);
            LogText.instance.ShowLog("Signup completed successfully");
            Debug.Log("Form upload complete!");
            ObjectsManager.instance.signupDataRoot = JsonUtility.FromJson<SignupData.Root>(request.downloadHandler.text);
            Debug.Log(ObjectsManager.instance.signupDataRoot);
        }
    }
    public static IEnumerator GetData(string address, UnityEngine.Events.UnityEvent successEvent)
    {
        var request = new UnityWebRequest(server + address, "Get");
        request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        var token = PlayerPrefs.GetString("token");
        Debug.Log("category data called");
        if (token != null)
        {
            request.SetRequestHeader("Authorization", "Bearer " + token);
            Debug.Log(token);
        }
        yield return request.SendWebRequest();
        if (request.result != UnityWebRequest.Result.Success)
        {
            ObjectsManager.instance.logErrorRoot = JsonUtility.FromJson<LogError.Root>(request.downloadHandler.text);
            LogText.instance.ShowLog("Operation Failed");
            Debug.Log(request.error);
            Debug.Log(request.downloadHandler.text);
        }
        else
        {
            if (address == categorieAdd)
            {
                // LogText.instance.ShowLog("Get category complete");
                Debug.Log("Get category complete");
                ObjectsManager.instance.categroyDataRoot = JsonUtility.FromJson<CategoryData.Root>(request.downloadHandler.text);
                Debug.Log(JsonUtility.FromJson<CategoryData.Root>(request.downloadHandler.text));
            }
            if (address.Contains(subCategorieAdd))
            {
                //LogText.instance.ShowLog("Get subcategroy complete");
                Debug.Log("Get subcategroy complete");
                ObjectsManager.instance.subCategoryRoot = JsonUtility.FromJson<SubCategoryData.Root>(request.downloadHandler.text);
                Debug.Log(JsonUtility.FromJson<SubCategoryData.Root>(request.downloadHandler.text));
            }
            if (address.Contains(subCategorieClothesAdd))
            {
                // LogText.instance.ShowLog("Get clothes complete");
                Debug.Log("Get clothes complete");
                ObjectsManager.instance.clothesDataRoot = JsonUtility.FromJson<ClothesData.Root>(request.downloadHandler.text);
                Debug.Log(JsonUtility.FromJson<SubCategoryData.Root>(request.downloadHandler.text));
            }
            if (address.Contains(AllCategoryCloth))
            {
                ObjectsManager.instance.clothesDataRoot = JsonUtility.FromJson<ClothesData.Root>(request.downloadHandler.text);
                Debug.Log("Searching Of Cloth is Working");
            }

            if (address == (orderList))
            {
                //Debug.LogError("Oreder List is Running");
                ObjectsManager.instance.allOderData = JsonUtility.FromJson<AllOderData.Root>(request.downloadHandler.text);
                Debug.Log("Order Data is ....................." + JsonUtility.FromJson<AllOderData.Root>(request.downloadHandler.text));
            }

            successEvent?.Invoke();
        }
    }
    public static IEnumerator PostRaw(string obj, string address, UnityEngine.Events.UnityEvent successEvent)
    {
        LoginForm LoginData;
        var request = new UnityWebRequest(server + address, "POST");
        // add for token
        request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        var token = PlayerPrefs.GetString("token");
        Debug.Log("category data called" + obj);
        if (token != null)
        {
            request.SetRequestHeader("Authorization", "Bearer " + token);
            Debug.Log(token);
        }
        //
        byte[] bodyRaw = Encoding.UTF8.GetBytes(obj);
        Debug.Log(bodyRaw.ToString());
        request.uploadHandler = (UploadHandler)new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");
        yield return request.SendWebRequest();
        if (request.result != UnityWebRequest.Result.Success)
        {
            ObjectsManager.instance.logErrorRoot = JsonUtility.FromJson<LogError.Root>(request.downloadHandler.text);
            LogText.instance.gameObject.SetActive(true);
            LogText.instance.ShowLog(ObjectsManager.instance.logErrorRoot.data.message);
            Debug.Log(request.error);
            Debug.Log(request.downloadHandler.text);
            Debug.Log(request.downloadHandler.text);
            UIManager.instance.LoadingPanelActivation(false);
        }
        else
        {

            var v = request.downloadHandler.text;
            Debug.Log(v);
            if (address == loginAdd)
            {
                LoginData = JsonUtility.FromJson<LoginForm>(obj);
                ObjectsManager.instance.userDataRoot = JsonUtility.FromJson<UserData.Root>(request.downloadHandler.text);
                PlayerPrefs.SetString("token", ObjectsManager.instance.userDataRoot.data.accessToken);
                Debug.Log("Token is" + ObjectsManager.instance.userDataRoot.data.accessToken);

                LogText.instance.ShowLog("login complete");
                Debug.Log("login complete");

                OnLoginDataHandler.OnLoginFaceCheckAndFetch(LoginData.email);
                // StartCoroutine(APIHelper.GetData(APIHelper.orderList, null));



                /*               if (PlayerPrefs.HasKey("Email") && PlayerPrefs.HasKey("Age"))
                               {
                                   if (ObjectsManager.instance.userDataRoot.data.user.email == PlayerPrefs.GetString("Email"))
                                   {
                                       Debug.Log("Email Exist and Do Nothing new");
                                   }
                                   else if(ObjectsManager.instance.userDataRoot.data.user.email != PlayerPrefs.GetString("Email"))
                                   {*/
                //PlayerPrefs.SetString("Email", ObjectsManager.instance.userDataRoot.data.user.email);

                /*                    }
                                }

                                if (!PlayerPrefs.HasKey("Email") && !PlayerPrefs.HasKey("Age"))
                                {
                                    PlayerPrefs.SetString("Email", ObjectsManager.instance.userDataRoot.data.user.email);
                                    PlayerPrefs.SetString("Password", ObjectsManager.instance.userDataRoot.data.user.password);
                                    PlayerPrefs.SetString("Age", ObjectsManager.instance.userDataRoot.data.user.dob);
                                    PlayerPrefs.SetString("Gender", ObjectsManager.instance.userDataRoot.data.user.gender);
                                }*/
                
                //              Authentication.instance.loginPanel.SetActive(false);
                //              Authentication.instance.mainPanel.SetActive(true);

            }
            if (address == forgetAdd)
            {
                LogText.instance.ShowLog("Verification code sent successfully");
                Debug.Log("forget complete");
                Authentication.instance.forgetPanel.SetActive(false);
                Authentication.instance.resetPanel.SetActive(true);
                ObjectsManager.instance.forgetDataRoot = JsonUtility.FromJson<ForgetData.Root>(request.downloadHandler.text);
            }
            if(address == verifyForgotPassword)
            {
                //LogText.instance.ShowLog("")
                LogText.instance.ShowLog("verification complete");

            }
            if (address == resetAdd)
            {
                LogText.instance.ShowLog("Password Update Successfully");
                Authentication.instance.loginPanel.SetActive(true);
                Authentication.instance.resetPanel.SetActive(false);
                Debug.Log("reset complete");
                // ObjectsManager.instance.userDataRoot = JsonUtility.FromJson<UserData.Root>(request.downloadHandler.text);
            }
/*            if(address == newOrderAdd)
            {
                
            }*/
            if(address == orderList)
            {
                ObjectsManager.instance.allOderData = JsonUtility.FromJson<AllOderData.Root>(request.downloadHandler.text);
                Debug.Log("Order Data is ....................." + JsonUtility.FromJson<AllOderData.Root>(request.downloadHandler.text));
                Debug.Log("OrderList is Placed");
                Debug.Log("Order Data is ....................." + JsonUtility.FromJson<AllOderData.Root>(request.downloadHandler.text));
            }

            successEvent?.Invoke();
            //PlayerPrefs.SetString("AccessToken");
        }
    }

    



}
public class OnLoginDataHandler
{
    public static void OnLoginFaceCheckAndFetch(string Email)
    {
        LogText.Email = Email;
        Debug.Log("New Email Set" + LogText.Email);
        
        PlayerPrefs.SetString("Email", LogText.instance.tempMail);
        
        PlayerPrefs.SetString("Password", LogText.instance.tempPassword);
        

        //PlayerPrefs.SetString("Password", ObjectsManager.instance.userDataRoot.data.user.password);
        PlayerPrefs.SetString("Age", ObjectsManager.instance.userDataRoot.data.user.dob);
        PlayerPrefs.SetString("Gender", ObjectsManager.instance.userDataRoot.data.user.gender);
        if (PlayerPrefs.GetString("FaceRecognizedEmail") == ObjectsManager.instance.userDataRoot.data.user.email)
        {
            Debug.Log("Login API Helper Is called in Email is REgistered as Face Recognition ");
            UIManager.instance.ShopButtonClick();
        }
        else
        {
            UIManager.instance.CheckUserJourney(false);
            Debug.Log("Login API Helper Is called in Email is not as Face Recognition ");
            //UIManager.instance.CameraButtonClick();
        }
       
        UIManager.instance.ShowSelectedCharacterInStart();
        UIManager.instance.LoadingPanelActivation(false);
        UIInitializer.instance.ProfileTextSetter(ObjectsManager.instance.userDataRoot.data.user.firstName);
        UIManager.instance.saveDataScript.ReadFirebaseData();


    }
   
    

}
class LoginForm
{
    public string email;
    public string password;
}