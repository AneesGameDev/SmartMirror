using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SliderButtonScript : MonoBehaviour
{
    [SerializeField]
    //private float _valueChangeBy= 0.1f;
    private Slider _currentSlider;
    //public GameObject Object1, Object2 ;
    public float SliderValue;
    private bool _rotateIs;
    public Image imageToFilled;
    public float currentSliderValuetotal;
    public float ration;
    // Start is called before the first frame update
    void Start()
    {
        currentSliderValuetotal = _currentSlider.maxValue + _currentSlider.minValue;

        _currentSlider = this.gameObject.GetComponent<Slider>();
        if (imageToFilled != null)
        {
            imageToFilled.fillAmount = 0f;
        }
       
    }

    // Update is called once per frame
    void Update()
    {
        
    }
/*    public void SliderIncreaseButtonMethod(GameObject sliderObj)
    {
        Slider slider = sliderObj.GetComponent<Slider>();
        slider.value += _valueChangeBy;
    }
    public void SliderDecreaseButtonMethod(GameObject sliderObj)
    {
        Slider slider = sliderObj.GetComponent<Slider>();
        slider.value -= _valueChangeBy;
    }*/

    public void DoubleColorSliderMethod()
    {
        if (_currentSlider.value < (currentSliderValuetotal) /2f)
        {
            float ration = 1f / (((currentSliderValuetotal)/2f)-_currentSlider.minValue);
          float  ration1 = ((currentSliderValuetotal / 2f) - (_currentSlider.value)) * ration;
           // float difference = value * ration;
            imageToFilled.fillAmount = ration1;
            // Object1.transform.Rotate(Vector3.forward * 180);
            //Object2.transform.Rotate(Vector3.forward * 180);
            //  _rotateIs = true;

            // _currentSlider.minValue = 0.5f;
            //_currentSlider.maxValue = 0f;
            //SliderValue = _currentSlider.value;//= 1.0f-_currentSlider.value;
            //Debug.Log("SLider Value " + SliderValue);

        }
        else
        {
            imageToFilled.fillAmount = 0f;
        }
        /*if (_rotateIs)
        {
            Debug.Log("SLider Value 1" + SliderValue);
            SliderValue = 1.0f - _currentSlider.value;
            
        }*/
       /* if (SliderValue > 0.5f)
        {
            Debug.Log("SLider Value 2" + SliderValue);
            Object1.transform.Rotate(Vector3.forward *0);
            Object2.transform.Rotate(Vector3.forward * 0);
            SliderValue = _currentSlider.value;
        }*/

    }

}
