using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SubcategoryComponent : MonoBehaviour
{
    public int id;
    public Text _name;
    public Image image;
    public void OnButtonClick()
    {
        SoundScript.instance.PlayButtonClickSound();
        ShopManager.instance.GetClotheSubcategory(id);
        SetColor();
    }
    public void SetColor()
    {
        foreach (var item in ShopUI.instance.subcateButtons)
        {
            item.transform.GetChild(0).GetComponent<Image>().color=Color.white;
        }
       transform.GetChild(0).GetComponent<Image>().color=ShopUI.instance.selectedColor;
    }
}
