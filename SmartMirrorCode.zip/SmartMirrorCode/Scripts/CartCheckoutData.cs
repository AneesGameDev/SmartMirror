using System;
using System.Collections.Generic;
[Serializable]
public class CartCheckoutData
{
public class CartCheckout
{
    public int id;
    public int sizeId;
    public string quantity;
    public string price;
    public string orderId;
    public DateTime createdAt;
    public DateTime updatedAt;
}
[Serializable]

public class Data
{
    public List<CartCheckout> cartCheckout;
    public NewOrder newOrder;
}
[Serializable]

public class NewOrder
{
    public int id;
    public int orderId;
    public int userId;
    public string status;
    public string totalAmount;
    public DateTime updatedAt;
    public DateTime createdAt;
}
[Serializable]

public class Root
{
    public string status;
    public bool error;
    public Data data;
}
}