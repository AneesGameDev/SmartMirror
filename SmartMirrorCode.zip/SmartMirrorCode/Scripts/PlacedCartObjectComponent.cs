using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlacedCartObjectComponent : MonoBehaviour
{

    public int id;
    public Image img;
    public Text price;
    public Text _name;
    public Text size;
    public Text status;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
