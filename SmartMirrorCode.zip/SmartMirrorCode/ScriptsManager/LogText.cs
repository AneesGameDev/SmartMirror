using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LogText : MonoBehaviour
{
    public GameObject logObject;
    public static LogText instance;
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
    }
    public Text logText;
    public void ShowLog(string log)
    {
        logObject.SetActive(true);
        logText.text = log;
        Invoke(nameof(ResetLog), 2);
    }
    void ResetLog()
    {
        logText.text = "";
        logObject.SetActive(false);
    }
}

