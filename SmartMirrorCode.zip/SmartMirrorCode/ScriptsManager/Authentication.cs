using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using System.Text.RegularExpressions;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class Authentication : MonoBehaviour
{
    public static Authentication instance;
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
    }
    public UnityEvent OnLoginEvent, OnSignupEvent, OnPasswordRest;
    public Text logtxt;
    [TextArea(3, 10)]
    public string result;
    [Header("sigin input feild")]
    public InputField idFieldSignin;
    public InputField passFieldSignin;
    public Button signinButton;
    [Header("sigup input feild")]
    public InputField firstNameFieldSignup;
    public InputField lastNameFieldSignup;
    public InputField idFieldSignup;
    public InputField passFieldSignup, passFieldSignup2;
    public Toggle termToggle;
    public Button signupButton;
    [Header("forget password feild")]
    public InputField idFieldForget;
    public Button forgetButton;
    [Header("Reset password feild")]
    public InputField emailFieldReset;
    public InputField passFieldReset;
    public InputField confrimPassFieldReset;
    public InputField forgetTokenFieldReset;

    public GameObject loginPanel, signupPanel, forgetPanel, resetPanel, mainPanel;
    public string forgotEmail;
    private void Start()
    {
        OnLoginEvent.AddListener(() =>
        {
            //ShopManager.instance.GetCategory();
            //ShopUI.instance.SetCategoryUI();
        });
        signinButton.onClick.AddListener(() => LoginClick());
        signupButton.onClick.AddListener(() => SignupClick());
        //  result= APIHelper.Login();
    }
    public void Subscribe()
    {

    }
    public string LoginValidation()
    {
        if (idFieldSignin.text == "")
        {
            return "Please enter your email";
        }
        if (!Regex.IsMatch(idFieldSignin.text, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase))
        {
            return "Please enter valid email";
        }
        if (passFieldSignin.text == "")
        {
            return "Please enter password";
        }
        if (passFieldSignin.text.Length < 4)
        {
            return "Password is too short!";
        }
        return "valid";
    }
    public void LoginClick()
    {
        if (LoginValidation() == "valid")
        {
            LoginForm obj = new LoginForm();
            obj.email = idFieldSignin.text;
            obj.password = passFieldSignin.text;
            StartCoroutine(APIHelper.PostRaw(JsonUtility.ToJson(obj), APIHelper.loginAdd, OnLoginEvent));
        }
        else
        {
            LogText.instance.ShowLog(LoginValidation());
        }
    }
    public string SignUpValidation()
    {
        if (firstNameFieldSignup.text == "")
        {
            return "Please enter your Full name";
        }
        if (!Regex.IsMatch(firstNameFieldSignup.text, @"^(?=[a-zA-Z])[-\w.]{0,23}([a-zA-Z\d]|(?<![-.])_)$", RegexOptions.IgnoreCase) /*|| !Regex.IsMatch(lastNameFieldSignup.text, @"^(?=[a-zA-Z])[-\w.]{0,23}([a-zA-Z\d]|(?<![-.])_)$", RegexOptions.IgnoreCase)*/)
        {
            return "Please enter valid name";
        }
        if (idFieldSignup.text == "")
        {
            return "Please enter your email";
        }
        if (!Regex.IsMatch(idFieldSignup.text, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase))
        {
            return "Please enter valid email";
        }
        if (passFieldSignup.text == "")
        {
            return "Please enter password";
        }
        if (passFieldSignup.text.Length < 4)
        {
            return "Password must be at least 4 letter";
        }
        if (passFieldSignup.text != passFieldSignup2.text)
        {
            return "Password does not match";
        }
        if (!termToggle.isOn)
        {
            return "Agree to our term and conditions to register account";
        }
        return "valid";
    }
    public void SignupClick()
    {
        if (SignUpValidation() == "valid")
        {
            StartCoroutine(APIHelper.Signup(firstNameFieldSignup.text, "", idFieldSignup.text, passFieldSignup.text, OnSignupEvent));
        }
        else
        {
            LogText.instance.ShowLog(SignUpValidation());
        }
    }
    public void ForgetClick()
    {
        if (!Regex.IsMatch(idFieldForget.text, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase))
        {
            LogText.instance.ShowLog("Please enter valid email");
            return;
        }
        ForgetForm obj = new ForgetForm();
        obj.email = idFieldForget.text;
        forgotEmail = idFieldForget.text;
        //obj.password = passFieldSignin.text;
        StartCoroutine(APIHelper.PostRaw(JsonUtility.ToJson(obj), APIHelper.forgetAdd, null));
    }
    public async void ResendClick(TMP_Text textMesh)
    {
        ForgetForm obj = new ForgetForm();
        obj.email = idFieldForget.text;
        forgotEmail = idFieldForget.text;
        StartCoroutine(APIHelper.PostRaw(JsonUtility.ToJson(obj), APIHelper.forgetAdd, null));
        textMesh.color  =Color.gray;
        await System.Threading.Tasks.Task.Delay(2000);
        textMesh.color  =Color.black;
    }
    public void ResetPassClick()
    {
        // if (!Regex.IsMatch(emailFieldReset.text, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase))
        // {
        //     ShowLog("Please enter valid email");
        //     return;
        // }
        if (passFieldReset.text != confrimPassFieldReset.text)
        {
            LogText.instance.ShowLog("Password does not match");
            return;
        }
        ResetForm obj = new ResetForm();
        //obj.email = emailFieldReset.text;
        obj.email = forgotEmail;
        obj.password = passFieldReset.text;
        obj.token = forgetTokenFieldReset.text;
        StartCoroutine(APIHelper.PostRaw(JsonUtility.ToJson(obj), APIHelper.resetAdd, OnPasswordRest));
    }
    public void GetTypes()
    {
        StartCoroutine(APIHelper.GetData(APIHelper.categorieAdd, null));
    }
    class LoginForm
    {
        public string email;
        public string password;
    }
    class ResetForm
    {
        public string email;
        public string password;
        public string token;
    }
    class ForgetForm
    {
        public string email;
    }
}
