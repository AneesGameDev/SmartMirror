using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CartObjectComponent : MonoBehaviour
{
    public int id;
    public Image img;
    public Text price;
    public Text _name;
    public Text size;
    public void OnDeleteButtonClick()
    {
        ShopManager.instance.newOderFormObj.cart.Remove(ShopManager.instance.newOderFormObj.cart.Find(r => r.sizeId == this.id));
        ObjectsManager.instance.userDataRoot.data.user.savedCart.Remove(ObjectsManager.instance.userDataRoot.data.user.savedCart.Find(r => r.ClotheSize.clothe.title == this._name.text));
        ShopManager.instance.newOderFormObj.status="saved";
        ShopManager.instance.NewOrderPost();
       // ShopManager.instance.cartdata.CartData.Remove(ShopManager.instance.cartdata.CartData.Find(r => r.id == this.id));
       // SaveData.SaveIntoJson<CartDataLocal.Root>(ShopManager.instance.cartdata);
        //ShopManager.instance.cartdata.CartData
        ShopUI.instance.SetCartsUI(false);
        Destroy(this.gameObject);
    }
}
