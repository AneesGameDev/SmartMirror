using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class SafeAreaPanel : MonoBehaviour
{
    public RectTransform rectTransform;
    private void OnEnable() {
        
        StartCoroutine(WhenKeyboardOpen());
    }
    private void Start() 
    {
    }
    private void SetUI(Rect rect)
    {
       // print(rect.x+rect.y+rect.height+rect.width+rect.yMax);
        Debug.Log("Rect set");
        rectTransform.offsetMin=new Vector2(rect.x,rect.y);
    }
    public IEnumerator WhenKeyboardOpen()
    {
        
       // SetUI(rect1);
        yield return new WaitUntil(()=>TouchScreenKeyboard.visible);
       // SetUI(rect1);
        print(GetKeyboardHeight(true));
        SetUI( new Rect(0,GetKeyboardHeight(true),0,0));
        yield return new WaitUntil(()=>!TouchScreenKeyboard.visible);
        print("reset panel");
        SetUI(new Rect());
        Start();
    }
        // some Android-specific constants (some have changed over time)
    private const string _playerClass = "com.unity3d.player.UnityPlayer";
    private const string _playerActivity = "currentActivity";
    private const string _playerObject = "mUnityPlayer";
    private const string _keyboardDialog = "mSoftInputDialog";
    private const string _keyboardRect = "android.graphics.Rect";
 
    private static int GetKeyboardHeight(bool includeInputField)
    {
        using (AndroidJavaObject unityActivity = new AndroidJavaClass(_playerClass).GetStatic<AndroidJavaObject>(_playerActivity))
        {
            AndroidJavaObject unityPlayer = unityActivity.Get<AndroidJavaObject>(_playerObject);
            AndroidJavaObject view = unityPlayer.Call<AndroidJavaObject>("getView");
 
            if (view == null)
            {
                return 0;
            }
 
            AndroidJavaObject dialog = unityPlayer.Get<AndroidJavaObject>(_keyboardDialog);
            while (dialog == null)
            {
                dialog = unityPlayer.Get<AndroidJavaObject>(_keyboardDialog);
            }
 
            int decorHeight = 0;
            if (includeInputField)
            {
                AndroidJavaObject decorView = dialog.Call<AndroidJavaObject>("getWindow").Call<AndroidJavaObject>("getDecorView");
                while (decorView == null)
                {
                    decorView = dialog.Call<AndroidJavaObject>("getWindow").Call<AndroidJavaObject>("getDecorView");
                }
                decorHeight = decorView.Call<int>("getHeight");
                while (decorHeight == 0)
                {
                    decorHeight = decorView.Call<int>("getHeight");
                }
                // Debug.Log("decorHeight ==> [ " + decorHeight + " ] ");
            }
 
            using (AndroidJavaObject rect = new AndroidJavaObject(_keyboardRect))
            {
                view.Call("getWindowVisibleDisplayFrame", rect);
                int frameHeight = rect.Call<int>("height");
                // Debug.Log("frameHeight ==> [ " + frameHeight + " ] ");
 
                int returnVal = Screen.height - frameHeight + decorHeight;
                // Debug.Log("returnVal ==> [ " + returnVal + " ] ");
                return returnVal;
            }
        }
    }
}
