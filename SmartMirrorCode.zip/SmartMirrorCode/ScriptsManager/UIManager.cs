using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;
using System.IO;
public class UIManager : MonoBehaviour
{
    public static UIManager instance;
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
    }
    public GameObject[] taskBarButtonSprites;
    public GameObject clotheFullViewPanel;

    public GameObject avatarCustomzPanel;
    public GameObject UMAObjectRoot;
    public GameObject UMAModelMale;
    public GameObject UMAModelFeMale;


    private void Update()
    {
        // if (Input.GetKeyDown(KeyCode.Space))
        // {
        //     ShopManager.instance.GetCategory();
        //     ShopUI.instance.SetCategoryUI();
        // }
    }
    public void ShopButtonClick(GameObject selectedObject)
    {
        taskBarButtonSprites.ToList().ForEach(g => g.SetActive(false));
        selectedObject.SetActive(true);
    }
    public void MirrorButtonClick(GameObject selectedObject)
    {
        taskBarButtonSprites.ToList().ForEach(g => g.SetActive(false));
        selectedObject.SetActive(true);
    }
    public void ProfileButtonClick(GameObject selectedObject)
    {
        taskBarButtonSprites.ToList().ForEach(g => g.SetActive(false));
        selectedObject.SetActive(true);
    }
    public void ContentTypePassword(InputField field)
    {
        field.contentType = InputField.ContentType.Password;
        field.ActivateInputField();
    }
    public void ContentTypeStandard(InputField field)
    {
        field.contentType = InputField.ContentType.Standard;
        field.ActivateInputField();
    }

    public void OnSaveAvatarClicked()
    { }

    public void OnShowAvatarCustomzPanel()
    {
        avatarCustomzPanel.SetActive(true);

        UMAObjectRoot.SetActive(true);

        UMAModelMale.SetActive(true);
    }
}
