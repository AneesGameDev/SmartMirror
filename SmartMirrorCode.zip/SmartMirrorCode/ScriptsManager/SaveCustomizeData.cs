using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using Firebase;
using Firebase.Extensions;
using Firebase.Storage;


public class CustomizeData
{
    public string _eyeColor;
    public string _hairColor;
    public string _skinColor;
    public float _shoulderValue;
    public float _chestValue;
    public float _waistValue;
    public float _hipsValue;
    public float _thighsValue;
    public bool male;
    //Value Of Customization Form is Below...............
    public float _chestFormValue;
    public float _legsWidthFormValue;
    public float _waistFormValue;
    public float _HeightFormValue;
    public float _legsLengthFormValue;
    public float _armLengthFormValue;
    
 
}

public class SaveCustomizeData : MonoBehaviour
{
    public CustomizeData dataObj = new CustomizeData();
    private string _path;

    FirebaseStorage storage;
    StorageReference storageReference;

    private void Awake()
    {
        _path = Application.persistentDataPath + "/CharacterCustomizeData.mirror";
        LoadData();
    }

    // Start is called before the first frame update
    private void OnEnable()
    {
       
    }
    void Start()
    {
        storage = FirebaseStorage.DefaultInstance;
        storageReference = storage.GetReferenceFromUrl("gs://mirrortracking.appspot.com/");

    }


/*    public void UploadJsonClick()
    {
        ShowLoadDialogCoroutine();

    }*/

    void UploadJsonData(string JsonObj)
    {


        //string JsonData = JsonUtility.ToJson(JsonObj);
        byte[] bytes = System.Text.Encoding.UTF8.GetBytes(JsonObj);
        //Editing Metadata
        var newMetadata = new MetadataChange();
            newMetadata.ContentType = "json";
       
        //Create a reference to where the file needs to be uploaded
        StorageReference uploadRef = storageReference.Child("Custom/CustomizeCharacter.json");
            Debug.Log("File upload started");
        uploadRef.PutBytesAsync(bytes, newMetadata).ContinueWithOnMainThread((task) =>
        {
            if(task.IsFaulted || task.IsCanceled)
            {
                Debug.Log(task.Exception.ToString());
            }
            else
            {
                Debug.Log("File Uploaded Successfully");
            }

        }
        );
/*            uploadRef.PutBytesAsync(bytes, newMetadata).ContinueWithOnMainThread((task) => {
                if (task.IsFaulted || task.IsCanceled)
                {
                    Debug.Log(task.Exception.ToString());
                }
                else
                {
                    Debug.Log("File Uploaded Successfully!");
                }
            });*/


        }
    


    public void SaveDataMethod()
    {
        SaveData();
    }
    // Update is called once per frame
    void Update()
    {
        
    }
    public void SaveData()
    {
        if (File.Exists(_path))
        {
            string JsonData = JsonUtility.ToJson(dataObj);
            File.WriteAllText(_path, JsonData);
            UploadJsonData(JsonData);
        }
        else
        {
            LoadData();
        }
    }
    private void LoadData()
    {
        if (File.Exists(_path))
        {
            string DataFile = File.ReadAllText(_path);
            dataObj = JsonUtility.FromJson<CustomizeData>(DataFile);
        }
        else
        {
            InitializeData();
            string JsonData = JsonUtility.ToJson(dataObj);
            File.WriteAllText(_path, JsonData);
        }
    }
   void InitializeData()
    {
        
    dataObj._eyeColor = "#0000000";
    dataObj._hairColor = "#0000000";
    dataObj._skinColor = "#F68B6D";
   dataObj._shoulderValue = 0.5f;
   dataObj._chestValue = 0.5f;
   dataObj._waistValue = 0.5f;
   dataObj._hipsValue = 0.5f;
   dataObj._thighsValue = 0.5f;




     dataObj._chestFormValue = 0.5f;
     dataObj._legsWidthFormValue=0.5f;
     dataObj._waistFormValue=0.5f;
     dataObj._HeightFormValue =0.5f;
     dataObj._legsLengthFormValue = 0.5f;
     dataObj._armLengthFormValue = 0.5f;



}
    
}
