using System.Collections;
using System.Collections.Generic;
using UnityEngine.Networking;
using UnityEngine;
using System.Net;
using System.Text;
using System.IO;
public static class APIHelper
{
    public delegate void OnLogin();
    public delegate void OnSignup();
    public delegate void OnForgetPassword();
    public delegate void OnResetPassword();
    //public delegate void OnLogin();
    public static string server = "http://54.234.242.24:8080/api/v1/";
    //local server
    //public static string server = "http://192.168.1.175:8080/api/v1/";
    public static string loginAdd = "auth/login";
    public static string forgetAdd = "auth/forgot-password";
    public static string resetAdd = "auth/reset-password";
    public static string categorieAdd = "category";
    public static string subCategorieAdd = "category/allsubcategory/";
    public static string subCategorieClothesAdd = "clothe/allsubcategoryclothes/";
    public static string postmanToken = "Token";
    public static string newOrderAdd="checkout";
    public static IEnumerator Login(string id, string password)
    {
        WWWForm form = new WWWForm();
        form.AddField("email", id);
        form.AddField("password", password);
        UnityWebRequest request = UnityWebRequest.Post(server + "auth/login", form);
        yield return request.SendWebRequest();
        if (request.result != UnityWebRequest.Result.Success)
        {
            Debug.Log(request.error);
        }
        else
        {
            Debug.Log("Form upload complete!");
        }
        // HttpWebResponse response=request.GetResponse();
        // StreamReader reader=new StreamReader(response.GetResponseStream());
        // string json=reader.ReadToEnd();
        // return json;
    }
    public static IEnumerator Signup(string firstName, string lastName, string id, string password,UnityEngine.Events.UnityEvent successEvent)
    {
        WWWForm form = new WWWForm();
        form.AddField("firstName", firstName);
        form.AddField("lastName", lastName);
        form.AddField("email", id);
        form.AddField("password", password);
        UnityWebRequest request = UnityWebRequest.Post(server + "auth/register", form);
        yield return request.SendWebRequest();
        if (request.result != UnityWebRequest.Result.Success)
        {
            ObjectsManager.instance.logErrorRoot = JsonUtility.FromJson<LogError.Root>(request.downloadHandler.text);
            LogText.instance.ShowLog(ObjectsManager.instance.logErrorRoot.data.message);
            Debug.Log(request.error);
            Debug.Log(request.downloadHandler.text);
        }
        else
        {
            successEvent?.Invoke();
            Authentication.instance.signupPanel.SetActive(false);
            Authentication.instance.loginPanel.SetActive(true);
            Debug.Log("Form upload complete!");
            ObjectsManager.instance.signupDataRoot = JsonUtility.FromJson<SignupData.Root>(request.downloadHandler.text);
            Debug.Log(ObjectsManager.instance.signupDataRoot);
        }
    }
    public static IEnumerator GetData(string address,UnityEngine.Events.UnityEvent successEvent)
    {
        var request = new UnityWebRequest(server + address, "Get");
        request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        var token = PlayerPrefs.GetString("token");
        Debug.Log("category data called");
        if (token != null)
        {
            request.SetRequestHeader("Authorization", "Bearer "+token);
            Debug.Log(token);
        }
        yield return request.SendWebRequest();
        if (request.result != UnityWebRequest.Result.Success)
        {
            ObjectsManager.instance.logErrorRoot = JsonUtility.FromJson<LogError.Root>(request.downloadHandler.text);
            LogText.instance.ShowLog(ObjectsManager.instance.logErrorRoot.data.message);
            Debug.Log(request.error);
            Debug.Log(request.downloadHandler.text);
        }
        else
        {
            if (address == categorieAdd)
            {
                Debug.Log("Get category complete");
                ObjectsManager.instance.categroyDataRoot = JsonUtility.FromJson<CategoryData.Root>(request.downloadHandler.text);
                Debug.Log(JsonUtility.FromJson<CategoryData.Root>(request.downloadHandler.text));
            }
            if (address.Contains(subCategorieAdd))
            {
                
                Debug.Log("Get subcategroy complete");
                ObjectsManager.instance.subCategoryRoot = JsonUtility.FromJson<SubCategoryData.Root>(request.downloadHandler.text);
                Debug.Log(JsonUtility.FromJson<SubCategoryData.Root>(request.downloadHandler.text));
            }
            if (address.Contains(subCategorieClothesAdd))
            {
                Debug.Log("Get clothes complete");
                ObjectsManager.instance.clothesDataRoot = JsonUtility.FromJson<ClothesData.Root>(request.downloadHandler.text);
                Debug.Log(JsonUtility.FromJson<SubCategoryData.Root>(request.downloadHandler.text));
            }
            successEvent?.Invoke();
        }
    }
    public static IEnumerator PostRaw(string obj, string address,UnityEngine.Events.UnityEvent successEvent)
    {
        var request = new UnityWebRequest(server + address, "POST");
        // add for token
        request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        var token = PlayerPrefs.GetString("token");
        Debug.Log("category data called");
        if (token != null)
        {
            request.SetRequestHeader("Authorization", "Bearer "+token);
            Debug.Log(token);
        }
        //
        byte[] bodyRaw = Encoding.UTF8.GetBytes(obj);
        Debug.Log(bodyRaw.ToString());
        request.uploadHandler = (UploadHandler)new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");
        yield return request.SendWebRequest();
        if (request.result != UnityWebRequest.Result.Success)
        {
            ObjectsManager.instance.logErrorRoot = JsonUtility.FromJson<LogError.Root>(request.downloadHandler.text);
            LogText.instance.gameObject.SetActive(true);
            LogText.instance.ShowLog(ObjectsManager.instance.logErrorRoot.data.message);
            Debug.Log(request.error);
            Debug.Log(request.downloadHandler.text);
        }
        else
        {
            successEvent?.Invoke();
            var v = request.downloadHandler.text;
            Debug.Log(v);
            if (address == loginAdd)
            {
                Debug.Log("login complete");
//              Authentication.instance.loginPanel.SetActive(false);
//              Authentication.instance.mainPanel.SetActive(true);
                ObjectsManager.instance.userDataRoot = JsonUtility.FromJson<UserData.Root>(request.downloadHandler.text);
                PlayerPrefs.SetString("token", ObjectsManager.instance.userDataRoot.data.accessToken);
            }
            if (address == forgetAdd)
            {
                Debug.Log("forget complete");
                Authentication.instance.forgetPanel.SetActive(false);
                Authentication.instance.resetPanel.SetActive(true);
                ObjectsManager.instance.forgetDataRoot = JsonUtility.FromJson<ForgetData.Root>(request.downloadHandler.text);
            }
            if (address == resetAdd)
            {
                Authentication.instance.loginPanel.SetActive(true);
                Authentication.instance.resetPanel.SetActive(false);
                Debug.Log("reset complete");
                // ObjectsManager.instance.userDataRoot = JsonUtility.FromJson<UserData.Root>(request.downloadHandler.text);
            }
            //PlayerPrefs.SetString("AccessToken");
        }
    }
}

