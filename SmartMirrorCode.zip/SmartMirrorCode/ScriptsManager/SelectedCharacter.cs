using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UMA;
using UMA.CharacterSystem;
using UnityEngine.UI;

public class SelectedCharacter : MonoBehaviour
{

    private int _characterSelection;
    [SerializeField]
    private GameObject _femalCharacter, _maleCharacter , UMAprefab;
    [HideInInspector]
    public DynamicCharacterAvatar _dynamicCharactermaleAvatar , _dynamicCharacterfemaleAvatar;
    private SaveCustomizeData saveData;
    //public GameObject MaleButton, FemalButton;
    private float startingPosition;
    private bool CanRotate , AreaClick;
    private float rotatespeed ;
    public Button _3DButton;
    //public Button AreaOfMovementCharacterBTN;
    private float _screenBottomLimit , _screenUpperLimit , _screenSmallPart;
    private GameObject move3DCharacter;
   // public RectTransform rect;
  //  private GameObject UIManagerObj;
  //  private CustomizeController _cutomizeController;

    // Start is called before the first frame update
    void Start()
    {
        _screenSmallPart = Screen.height / 12;
        _screenBottomLimit = Screen.height / 2 + _screenSmallPart;
        _screenUpperLimit = Screen.height - _screenSmallPart; 
        CanRotate = false;
        rotatespeed = 300f;


        //if (MaleButton && FemalButton != null) MaleButton.SetActive(true); FemalButton.SetActive(true);
        saveData = FindObjectOfType<SaveCustomizeData>();
        //_cutomizeController = UIManagerObj.GetComponent<CustomizeController>();
        //UMA.UMADNA
        _3DButton.gameObject.GetComponent<Image>().color = Color.white;
        _3DButton.onClick.AddListener(()=>ButtonClick3Dview());
        //AreaOfMovementCharacterBTN.onClick.AddListener(() => DragClickCharacter());
        //AreaOfMovementCharacterBTN. AddListener(() => DragClickCharacter());
        ShowSelectedCharacter();

    }
    private void OnEnable()
    {
        
    }

    // Update is called once per frame
    void Update()
    {


        if (Input.touchCount > 0 && CanRotate )
        {
           


            Debug.Log("Touch Count is Working");
            Touch touch = Input.GetTouch(0);
            
            switch (touch.phase)
            {
                case TouchPhase.Began:
                    startingPosition = touch.position.x;
                    break;
                case TouchPhase.Moved:
                   if(touch.position.y> _screenBottomLimit && touch.position.y < _screenUpperLimit) { 
                    if (startingPosition > touch.position.x)
                    {
                            move3DCharacter.transform.Rotate(Vector3.up, rotatespeed * Time.deltaTime);
                    }
                    else if (startingPosition < touch.position.x)
                    {
                            move3DCharacter.transform.Rotate(Vector3.up, -rotatespeed * Time.deltaTime);
                    }
                    }
                    break;
                case TouchPhase.Ended:
                    Debug.Log("Touch Phase Ended.");
                    break;
                case TouchPhase.Stationary:
                    startingPosition = touch.position.x;
                    break;
           
        }
        }
    }


    public void SelectionCharacterButton(int param)
    {
        if (UMAprefab != null) UMAprefab.SetActive(false);
        _characterSelection = param;
       
    }
   
    
    public void ShowSelectedCharacter()
    {
        //if (UMAprefab != null) UMAprefab.SetActive(false);
        if (UMAprefab != null) UMAprefab.SetActive(true);

        if (UMAprefab.activeSelf)
        {

           
            saveData.dataObj.male = true;
            _maleCharacter.SetActive(true);
            _femalCharacter.SetActive(false);
            _dynamicCharactermaleAvatar = _maleCharacter.GetComponent<DynamicCharacterAvatar>();
            move3DCharacter = _maleCharacter;

            /*            if(_characterSelection == 0)
                        {
                            MaleButton.SetActive(true);
                            FemalButton.SetActive(false);
                            saveData.dataObj.male = true;
                            _maleCharacter.SetActive(true);
                            _femalCharacter.SetActive(false);
                            _dynamicCharactermaleAvatar = _maleCharacter.GetComponent<DynamicCharacterAvatar>();
                             move3DCharacter = _maleCharacter;

                        }
                        else if(_characterSelection==1)
                        {
                            MaleButton.SetActive(false);
                            FemalButton.SetActive(true);
                            saveData.dataObj.male = false;
                            _femalCharacter.SetActive(true);
                            _maleCharacter.SetActive(false);
                            _dynamicCharacterfemaleAvatar = _femalCharacter.GetComponent<DynamicCharacterAvatar>();
                            move3DCharacter = _femalCharacter; 

                        }*/
            //_cutomizeController._avatar = _dynamicCharacterAvatar;

        }
    }


    public void ButtonClick3Dview()
    {
        if (!CanRotate)
        {
            CanRotate = true;
            _3DButton.gameObject.GetComponent<Image>().color = Color.black;
        }
        else if(CanRotate)
        {
            Reset3DViewObject();
        }
    }

    public void Reset3DViewObject()
    {
        CanRotate = false;
        move3DCharacter.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
        _3DButton.gameObject.GetComponent<Image>().color = Color.white;
    }

}
